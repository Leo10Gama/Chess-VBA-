﻿Public Class fmChess
    'Leonardo Gama
    'Date of previous update: 01/07/19
    'Special thanks to Eric
    Dim board(7, 7) As String
    Dim selectable(7, 7) As Boolean
    Dim linesofCheck(7, 7) As Boolean
    Dim turn As Char = "W"
    Dim selectedX As Integer = Nothing
    Dim selectedY As Integer = Nothing
    Dim glowColor As Color = Color.RoyalBlue
    Dim lightTile As Color = Color.SandyBrown
    Dim darkTile As Color = Color.SaddleBrown
    Dim WKCastle As Boolean = False
    Dim WQCastle As Boolean = False
    Dim BKCastle As Boolean = False
    Dim BQCastle As Boolean = False
    Dim wTimeS As Integer
    Dim wTimeM As Integer
    Dim bTimeS As Integer
    Dim bTimeM As Integer
    Dim boardRotate As Boolean = False
    Dim timersOn As Boolean = False

    Private Sub NewGame(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewGameToolStripMenuItem.Click
        For x As Integer = 0 To 7
            For y As Integer = 0 To 7
                board(x, y) = Nothing
            Next
        Next
        board(0, 0) = "BR"
        board(1, 0) = "BN"
        board(2, 0) = "BB"
        board(3, 0) = "BQ"
        board(4, 0) = "BK"
        board(5, 0) = "BB"
        board(6, 0) = "BN"
        board(7, 0) = "BR"
        board(0, 1) = "BP"
        board(1, 1) = "BP"
        board(2, 1) = "BP"
        board(3, 1) = "BP"
        board(4, 1) = "BP"
        board(5, 1) = "BP"
        board(6, 1) = "BP"
        board(7, 1) = "BP"
        board(0, 6) = "WP"
        board(1, 6) = "WP"
        board(2, 6) = "WP"
        board(3, 6) = "WP"
        board(4, 6) = "WP"
        board(5, 6) = "WP"
        board(6, 6) = "WP"
        board(7, 6) = "WP"
        board(0, 7) = "WR"
        board(1, 7) = "WN"
        board(2, 7) = "WB"
        board(3, 7) = "WQ"
        board(4, 7) = "WK"
        board(5, 7) = "WB"
        board(6, 7) = "WN"
        board(7, 7) = "WR"
        WKCastle = True
        WQCastle = True
        BKCastle = True
        BQCastle = True
        turn = "W"
        ResetSelection()
        UpdateBoard()
    End Sub
    Private Sub SquareClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt0000.Click, _
    bt0001.Click, bt0002.Click, bt0003.Click, bt0004.Click, bt0005.Click, bt0006.Click, bt0007.Click, bt0100.Click, _
    bt0101.Click, bt0102.Click, bt0103.Click, bt0104.Click, bt0105.Click, bt0106.Click, bt0107.Click, bt0200.Click, _
    bt0201.Click, bt0202.Click, bt0203.Click, bt0204.Click, bt0205.Click, bt0206.Click, bt0207.Click, bt0300.Click, _
    bt0301.Click, bt0302.Click, bt0303.Click, bt0304.Click, bt0305.Click, bt0306.Click, bt0307.Click, bt0400.Click, _
    bt0401.Click, bt0402.Click, bt0403.Click, bt0404.Click, bt0405.Click, bt0406.Click, bt0407.Click, bt0500.Click, _
    bt0501.Click, bt0502.Click, bt0503.Click, bt0504.Click, bt0505.Click, bt0506.Click, bt0507.Click, bt0600.Click, _
    bt0601.Click, bt0602.Click, bt0603.Click, bt0604.Click, bt0605.Click, bt0606.Click, bt0607.Click, bt0700.Click, _
    bt0701.Click, bt0702.Click, bt0703.Click, bt0704.Click, bt0705.Click, bt0706.Click, bt0707.Click
        Dim clickedSquareX As Integer
        Dim clickedSquareY As Integer
        If turn = "W" Or boardRotate = False Then
            clickedSquareX = Val(sender.tag \ 100)
            clickedSquareY = Val(sender.tag Mod 100)
        ElseIf turn = "B" And boardRotate = True Then
            clickedSquareX = ((Val(sender.tag \ 100)) * -1) + 7
            clickedSquareY = ((Val(sender.tag Mod 100)) * -1) + 7
        End If
        Dim piece As Char = board(clickedSquareX, clickedSquareY)
        'Verify who's turn it is
        If board(clickedSquareX, clickedSquareY) <> Nothing Then    'Check that there is a piece on that square
            If board(clickedSquareX, clickedSquareY).Remove(1, 1) = turn Then   'Confirm the piece is allowed to move
                'Check which piece is on that square
                ResetSelection()
                Select Case board(clickedSquareX, clickedSquareY).Remove(0, 1)
                    'Pawn movement options
                    Case "P"                                'PAWN MOVEMENT
                        Call PawnMove(clickedSquareX, clickedSquareY)
                    Case "R"                                'ROOK MOVEMENT
                        If turn = "W" Then
                            Call RookMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                        ElseIf turn = "B" Then
                            Call RookMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                        End If
                    Case "N"                                'KNIGHT MOVEMENT
                        If turn = "W" Then
                            Call KnightMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                        ElseIf turn = "B" Then
                            Call KnightMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                        End If
                    Case "B"
                        If turn = "W" Then
                            Call BishopMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                        ElseIf turn = "B" Then
                            Call BishopMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                        End If
                    Case "Q"
                        If turn = "W" Then
                            Call RookMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                            Call BishopMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                        ElseIf turn = "B" Then
                            Call RookMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                            Call BishopMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                        End If
                    Case "K"
                        If turn = "W" Then
                            Call KingMove(clickedSquareX, clickedSquareY, PieceColor("Wx"))
                        ElseIf turn = "B" Then
                            Call KingMove(clickedSquareX, clickedSquareY, PieceColor("Bx"))
                        End If
                End Select
                selectedX = clickedSquareX
                selectedY = clickedSquareY
                DisplaySelection()
            ElseIf board(clickedSquareX, clickedSquareY).Remove(1, 1) <> turn Then          'KILLING
                If selectable(clickedSquareX, clickedSquareY) = True Then
                    Dim tempMyPiece As String = board(selectedX, selectedY)
                    Dim tempOtherPiece As String = board(clickedSquareX, clickedSquareY)
                    board(clickedSquareX, clickedSquareY) = tempMyPiece
                    board(selectedX, selectedY) = Nothing
                    Call ResetC4C()
                    Call CheckForCheck()
                    If turn = "W" Then
                        For x As Integer = 0 To 7
                            For y As Integer = 0 To 7
                                If board(x, y) = "WK" Then                      'Check if it's a legal move
                                    If linesofCheck(x, y) = True Then               'Not legal
                                        board(selectedX, selectedY) = tempMyPiece
                                        board(clickedSquareX, clickedSquareY) = tempOtherPiece
                                        Call ResetC4C()
                                        Call CheckForCheck()
                                    Else                                            'Is legal
                                        turn = "B"
                                        If board(0, 7) <> "WR" Then
                                            WQCastle = False
                                        End If
                                        If board(7, 7) <> "WR" Then
                                            WKCastle = False
                                        End If
                                        If board(4, 7) <> "WK" Or board(6, 7) <> "WK" Or board(2, 7) <> "WK" Then
                                            WQCastle = False
                                            WKCastle = False
                                        End If
                                        Call ResetC4C()
                                        Call PromotePawn()
                                        Call CheckForCheck()
                                    End If
                                End If
                            Next
                        Next
                    Else
                        For x As Integer = 0 To 7
                            For y As Integer = 0 To 7
                                If board(x, y) = "BK" Then
                                    If linesofCheck(x, y) = True Then
                                        board(selectedX, selectedY) = tempMyPiece
                                        board(clickedSquareX, clickedSquareY) = tempOtherPiece
                                        Call ResetC4C()
                                        Call CheckForCheck()
                                    Else
                                        turn = "W"
                                        If board(0, 0) <> "BR" Then
                                            BQCastle = False
                                        End If
                                        If board(7, 0) <> "BR" Then
                                            BKCastle = False
                                        End If
                                        If board(4, 0) <> "BK" Or board(6, 0) <> "BK" Or board(2, 0) <> "BK" Then
                                            BQCastle = False
                                            BKCastle = False
                                        End If
                                        Call ResetC4C()
                                        Call PromotePawn()
                                        Call CheckForCheck()
                                    End If
                                End If
                            Next
                        Next
                    End If
                    tempMyPiece = Nothing
                    tempOtherPiece = Nothing
                    selectedX = Nothing
                    selectedY = Nothing
                End If
                Call UpdateBoard()
                Call ResetSelection()
            End If
        Else                                                                        'MOVING TO AN EMPTY SQUARE
            If selectable(clickedSquareX, clickedSquareY) = True Then
                Dim tempMyPiece As String = board(selectedX, selectedY)
                board(clickedSquareX, clickedSquareY) = tempMyPiece
                board(selectedX, selectedY) = Nothing
                Call ResetC4C()
                Call CheckForCheck()
                If turn = "W" Then
                    For x As Integer = 0 To 7
                        For y As Integer = 0 To 7
                            If board(x, y) = "WK" Then
                                If linesofCheck(x, y) = True Then
                                    board(selectedX, selectedY) = tempMyPiece
                                    board(clickedSquareX, clickedSquareY) = Nothing
                                    Call ResetC4C()
                                    Call CheckForCheck()
                                Else
                                    turn = "B"
                                    If board(6, 7) = "WK" And WKCastle = True Then
                                        board(7, 7) = Nothing
                                        board(5, 7) = "WR"
                                        WQCastle = False
                                        WKCastle = False
                                    End If
                                    If board(2, 7) = "WK" And WQCastle = True Then
                                        board(0, 7) = Nothing
                                        board(3, 7) = "WR"
                                        WQCastle = False
                                        WKCastle = False
                                    End If
                                    If board(0, 7) <> "WR" Then
                                        WQCastle = False
                                    End If
                                    If board(7, 7) <> "WR" Then
                                        WKCastle = False
                                    End If
                                    If board(4, 7) <> "WK" Or board(6, 7) <> "WK" Or board(2, 7) <> "WK" Then
                                        WQCastle = False
                                        WKCastle = False
                                    End If
                                    Call ResetC4C()
                                    Call PromotePawn()
                                    Call CheckForCheck()
                                End If
                            End If
                        Next
                    Next
                Else
                    For x As Integer = 0 To 7
                        For y As Integer = 0 To 7
                            If board(x, y) = "BK" Then
                                If linesofCheck(x, y) = True Then
                                    board(selectedX, selectedY) = tempMyPiece
                                    board(clickedSquareX, clickedSquareY) = Nothing
                                    Call ResetC4C()
                                    Call CheckForCheck()
                                Else
                                    turn = "W"
                                    If board(6, 0) = "BK" Then
                                        board(7, 0) = Nothing
                                        board(5, 0) = "BR"
                                        BQCastle = False
                                        BKCastle = False
                                    End If
                                    If board(2, 0) = "BK" Then
                                        board(0, 0) = Nothing
                                        board(3, 0) = "BR"
                                        BQCastle = False
                                        BKCastle = False
                                    End If
                                    If board(0, 0) <> "BR" Then
                                        BQCastle = False
                                    End If
                                    If board(7, 0) <> "BR" Then
                                        BKCastle = False
                                    End If
                                    If board(4, 0) <> "BK" Or board(6, 0) <> "BK" Or board(2, 0) <> "BK" Then
                                        BQCastle = False
                                        BKCastle = False
                                    End If
                                    Call ResetC4C()
                                    Call PromotePawn()
                                    Call CheckForCheck()
                                End If
                            End If
                        Next
                    Next
                End If
                tempMyPiece = Nothing
            End If
            Call UpdateBoard()
            Call ResetSelection()
            If timersOn = True Then
                Call UpdateTimers()
            End If
        End If
    End Sub

    Sub UpdateBoard()
        If turn = "W" Or boardRotate = False Then
            Me.bt0000.Image = StringToPiece(board(0, 0))
            Me.bt0100.Image = StringToPiece(board(1, 0))
            Me.bt0200.Image = StringToPiece(board(2, 0))
            Me.bt0300.Image = StringToPiece(board(3, 0))
            Me.bt0400.Image = StringToPiece(board(4, 0))
            Me.bt0500.Image = StringToPiece(board(5, 0))
            Me.bt0600.Image = StringToPiece(board(6, 0))
            Me.bt0700.Image = StringToPiece(board(7, 0))
            Me.bt0001.Image = StringToPiece(board(0, 1))
            Me.bt0101.Image = StringToPiece(board(1, 1))
            Me.bt0201.Image = StringToPiece(board(2, 1))
            Me.bt0301.Image = StringToPiece(board(3, 1))
            Me.bt0401.Image = StringToPiece(board(4, 1))
            Me.bt0501.Image = StringToPiece(board(5, 1))
            Me.bt0601.Image = StringToPiece(board(6, 1))
            Me.bt0701.Image = StringToPiece(board(7, 1))
            Me.bt0002.Image = StringToPiece(board(0, 2))
            Me.bt0102.Image = StringToPiece(board(1, 2))
            Me.bt0202.Image = StringToPiece(board(2, 2))
            Me.bt0302.Image = StringToPiece(board(3, 2))
            Me.bt0402.Image = StringToPiece(board(4, 2))
            Me.bt0502.Image = StringToPiece(board(5, 2))
            Me.bt0602.Image = StringToPiece(board(6, 2))
            Me.bt0702.Image = StringToPiece(board(7, 2))
            Me.bt0003.Image = StringToPiece(board(0, 3))
            Me.bt0103.Image = StringToPiece(board(1, 3))
            Me.bt0203.Image = StringToPiece(board(2, 3))
            Me.bt0303.Image = StringToPiece(board(3, 3))
            Me.bt0403.Image = StringToPiece(board(4, 3))
            Me.bt0503.Image = StringToPiece(board(5, 3))
            Me.bt0603.Image = StringToPiece(board(6, 3))
            Me.bt0703.Image = StringToPiece(board(7, 3))
            Me.bt0004.Image = StringToPiece(board(0, 4))
            Me.bt0104.Image = StringToPiece(board(1, 4))
            Me.bt0204.Image = StringToPiece(board(2, 4))
            Me.bt0304.Image = StringToPiece(board(3, 4))
            Me.bt0404.Image = StringToPiece(board(4, 4))
            Me.bt0504.Image = StringToPiece(board(5, 4))
            Me.bt0604.Image = StringToPiece(board(6, 4))
            Me.bt0704.Image = StringToPiece(board(7, 4))
            Me.bt0005.Image = StringToPiece(board(0, 5))
            Me.bt0105.Image = StringToPiece(board(1, 5))
            Me.bt0205.Image = StringToPiece(board(2, 5))
            Me.bt0305.Image = StringToPiece(board(3, 5))
            Me.bt0405.Image = StringToPiece(board(4, 5))
            Me.bt0505.Image = StringToPiece(board(5, 5))
            Me.bt0605.Image = StringToPiece(board(6, 5))
            Me.bt0705.Image = StringToPiece(board(7, 5))
            Me.bt0006.Image = StringToPiece(board(0, 6))
            Me.bt0106.Image = StringToPiece(board(1, 6))
            Me.bt0206.Image = StringToPiece(board(2, 6))
            Me.bt0306.Image = StringToPiece(board(3, 6))
            Me.bt0406.Image = StringToPiece(board(4, 6))
            Me.bt0506.Image = StringToPiece(board(5, 6))
            Me.bt0606.Image = StringToPiece(board(6, 6))
            Me.bt0706.Image = StringToPiece(board(7, 6))
            Me.bt0007.Image = StringToPiece(board(0, 7))
            Me.bt0107.Image = StringToPiece(board(1, 7))
            Me.bt0207.Image = StringToPiece(board(2, 7))
            Me.bt0307.Image = StringToPiece(board(3, 7))
            Me.bt0407.Image = StringToPiece(board(4, 7))
            Me.bt0507.Image = StringToPiece(board(5, 7))
            Me.bt0607.Image = StringToPiece(board(6, 7))
            Me.bt0707.Image = StringToPiece(board(7, 7))
        ElseIf turn = "B" And boardRotate = True Then
            Me.bt0000.Image = StringToPiece(board(7, 7))
            Me.bt0100.Image = StringToPiece(board(6, 7))
            Me.bt0200.Image = StringToPiece(board(5, 7))
            Me.bt0300.Image = StringToPiece(board(4, 7))
            Me.bt0400.Image = StringToPiece(board(3, 7))
            Me.bt0500.Image = StringToPiece(board(2, 7))
            Me.bt0600.Image = StringToPiece(board(1, 7))
            Me.bt0700.Image = StringToPiece(board(0, 7))
            Me.bt0001.Image = StringToPiece(board(7, 6))
            Me.bt0101.Image = StringToPiece(board(6, 6))
            Me.bt0201.Image = StringToPiece(board(5, 6))
            Me.bt0301.Image = StringToPiece(board(4, 6))
            Me.bt0401.Image = StringToPiece(board(3, 6))
            Me.bt0501.Image = StringToPiece(board(2, 6))
            Me.bt0601.Image = StringToPiece(board(1, 6))
            Me.bt0701.Image = StringToPiece(board(0, 6))
            Me.bt0002.Image = StringToPiece(board(7, 5))
            Me.bt0102.Image = StringToPiece(board(6, 5))
            Me.bt0202.Image = StringToPiece(board(5, 5))
            Me.bt0302.Image = StringToPiece(board(4, 5))
            Me.bt0402.Image = StringToPiece(board(3, 5))
            Me.bt0502.Image = StringToPiece(board(2, 5))
            Me.bt0602.Image = StringToPiece(board(1, 5))
            Me.bt0702.Image = StringToPiece(board(0, 5))
            Me.bt0003.Image = StringToPiece(board(7, 4))
            Me.bt0103.Image = StringToPiece(board(6, 4))
            Me.bt0203.Image = StringToPiece(board(5, 4))
            Me.bt0303.Image = StringToPiece(board(4, 4))
            Me.bt0403.Image = StringToPiece(board(3, 4))
            Me.bt0503.Image = StringToPiece(board(2, 4))
            Me.bt0603.Image = StringToPiece(board(1, 4))
            Me.bt0703.Image = StringToPiece(board(0, 4))
            Me.bt0004.Image = StringToPiece(board(7, 3))
            Me.bt0104.Image = StringToPiece(board(6, 3))
            Me.bt0204.Image = StringToPiece(board(5, 3))
            Me.bt0304.Image = StringToPiece(board(4, 3))
            Me.bt0404.Image = StringToPiece(board(3, 3))
            Me.bt0504.Image = StringToPiece(board(2, 3))
            Me.bt0604.Image = StringToPiece(board(1, 3))
            Me.bt0704.Image = StringToPiece(board(0, 3))
            Me.bt0005.Image = StringToPiece(board(7, 2))
            Me.bt0105.Image = StringToPiece(board(6, 2))
            Me.bt0205.Image = StringToPiece(board(5, 2))
            Me.bt0305.Image = StringToPiece(board(4, 2))
            Me.bt0405.Image = StringToPiece(board(3, 2))
            Me.bt0505.Image = StringToPiece(board(2, 2))
            Me.bt0605.Image = StringToPiece(board(1, 2))
            Me.bt0705.Image = StringToPiece(board(0, 2))
            Me.bt0006.Image = StringToPiece(board(7, 1))
            Me.bt0106.Image = StringToPiece(board(6, 1))
            Me.bt0206.Image = StringToPiece(board(5, 1))
            Me.bt0306.Image = StringToPiece(board(4, 1))
            Me.bt0406.Image = StringToPiece(board(3, 1))
            Me.bt0506.Image = StringToPiece(board(2, 1))
            Me.bt0606.Image = StringToPiece(board(1, 1))
            Me.bt0706.Image = StringToPiece(board(0, 1))
            Me.bt0007.Image = StringToPiece(board(7, 0))
            Me.bt0107.Image = StringToPiece(board(6, 0))
            Me.bt0207.Image = StringToPiece(board(5, 0))
            Me.bt0307.Image = StringToPiece(board(4, 0))
            Me.bt0407.Image = StringToPiece(board(3, 0))
            Me.bt0507.Image = StringToPiece(board(2, 0))
            Me.bt0607.Image = StringToPiece(board(1, 0))
            Me.bt0707.Image = StringToPiece(board(0, 0))
        End If
        Me.bt0000.ForeColor = PieceColor(board(0, 0))
        Me.bt0100.ForeColor = PieceColor(board(1, 0))
        Me.bt0200.ForeColor = PieceColor(board(2, 0))
        Me.bt0300.ForeColor = PieceColor(board(3, 0))
        Me.bt0400.ForeColor = PieceColor(board(4, 0))
        Me.bt0500.ForeColor = PieceColor(board(5, 0))
        Me.bt0600.ForeColor = PieceColor(board(6, 0))
        Me.bt0700.ForeColor = PieceColor(board(7, 0))
        Me.bt0001.ForeColor = PieceColor(board(0, 1))
        Me.bt0101.ForeColor = PieceColor(board(1, 1))
        Me.bt0201.ForeColor = PieceColor(board(2, 1))
        Me.bt0301.ForeColor = PieceColor(board(3, 1))
        Me.bt0401.ForeColor = PieceColor(board(4, 1))
        Me.bt0501.ForeColor = PieceColor(board(5, 1))
        Me.bt0601.ForeColor = PieceColor(board(6, 1))
        Me.bt0701.ForeColor = PieceColor(board(7, 1))
        Me.bt0002.ForeColor = PieceColor(board(0, 2))
        Me.bt0102.ForeColor = PieceColor(board(1, 2))
        Me.bt0202.ForeColor = PieceColor(board(2, 2))
        Me.bt0302.ForeColor = PieceColor(board(3, 2))
        Me.bt0402.ForeColor = PieceColor(board(4, 2))
        Me.bt0502.ForeColor = PieceColor(board(5, 2))
        Me.bt0602.ForeColor = PieceColor(board(6, 2))
        Me.bt0702.ForeColor = PieceColor(board(7, 2))
        Me.bt0003.ForeColor = PieceColor(board(0, 3))
        Me.bt0103.ForeColor = PieceColor(board(1, 3))
        Me.bt0203.ForeColor = PieceColor(board(2, 3))
        Me.bt0303.ForeColor = PieceColor(board(3, 3))
        Me.bt0403.ForeColor = PieceColor(board(4, 3))
        Me.bt0503.ForeColor = PieceColor(board(5, 3))
        Me.bt0603.ForeColor = PieceColor(board(6, 3))
        Me.bt0703.ForeColor = PieceColor(board(7, 3))
        Me.bt0004.ForeColor = PieceColor(board(0, 4))
        Me.bt0104.ForeColor = PieceColor(board(1, 4))
        Me.bt0204.ForeColor = PieceColor(board(2, 4))
        Me.bt0304.ForeColor = PieceColor(board(3, 4))
        Me.bt0404.ForeColor = PieceColor(board(4, 4))
        Me.bt0504.ForeColor = PieceColor(board(5, 4))
        Me.bt0604.ForeColor = PieceColor(board(6, 4))
        Me.bt0704.ForeColor = PieceColor(board(7, 4))
        Me.bt0005.ForeColor = PieceColor(board(0, 5))
        Me.bt0105.ForeColor = PieceColor(board(1, 5))
        Me.bt0205.ForeColor = PieceColor(board(2, 5))
        Me.bt0305.ForeColor = PieceColor(board(3, 5))
        Me.bt0405.ForeColor = PieceColor(board(4, 5))
        Me.bt0505.ForeColor = PieceColor(board(5, 5))
        Me.bt0605.ForeColor = PieceColor(board(6, 5))
        Me.bt0705.ForeColor = PieceColor(board(7, 5))
        Me.bt0006.ForeColor = PieceColor(board(0, 6))
        Me.bt0106.ForeColor = PieceColor(board(1, 6))
        Me.bt0206.ForeColor = PieceColor(board(2, 6))
        Me.bt0306.ForeColor = PieceColor(board(3, 6))
        Me.bt0406.ForeColor = PieceColor(board(4, 6))
        Me.bt0506.ForeColor = PieceColor(board(5, 6))
        Me.bt0606.ForeColor = PieceColor(board(6, 6))
        Me.bt0706.ForeColor = PieceColor(board(7, 6))
        Me.bt0007.ForeColor = PieceColor(board(0, 7))
        Me.bt0107.ForeColor = PieceColor(board(1, 7))
        Me.bt0207.ForeColor = PieceColor(board(2, 7))
        Me.bt0307.ForeColor = PieceColor(board(3, 7))
        Me.bt0407.ForeColor = PieceColor(board(4, 7))
        Me.bt0507.ForeColor = PieceColor(board(5, 7))
        Me.bt0607.ForeColor = PieceColor(board(6, 7))
        Me.bt0707.ForeColor = PieceColor(board(7, 7))
    End Sub

    Function StringToPiece(ByVal piece As String)
        If piece <> Nothing Then
            Select Case piece.Remove(1, 1)
                Case "W"
                    Select Case piece.Remove(0, 1)
                        Case "P"
                            Return My.Resources.WP
                        Case "R"
                            Return My.Resources.WR
                        Case "N"
                            Return My.Resources.WN
                        Case "B"
                            Return My.Resources.WB
                        Case "Q"
                            Return My.Resources.WQ
                        Case "K"
                            Return My.Resources.WK
                        Case Else
                            Return Nothing
                    End Select
                Case "B"
                    Select Case piece.Remove(0, 1)
                        Case "P"
                            Return My.Resources.BP
                        Case "R"
                            Return My.Resources.BR
                        Case "N"
                            Return My.Resources.BN
                        Case "B"
                            Return My.Resources.BB
                        Case "Q"
                            Return My.Resources.BQ
                        Case "K"
                            Return My.Resources.BK
                        Case Else
                            Return Nothing
                    End Select
            End Select
        End If
        Return Nothing
    End Function
    Function PieceColor(ByVal piece As String)
        If piece <> Nothing Then
            Select Case piece.Remove(1, 1)
                Case "W"
                    Return Color.White
                Case "B"
                    Return Color.Black
                Case Else
                    Return Color.DimGray
            End Select
        Else
            Return Color.DimGray
        End If
    End Function

    Sub DisplaySelection()
        If turn = "W" Or boardRotate = False Then
            For x As Integer = 0 To 7
                For y As Integer = 0 To 7
                    If selectable(x, y) = True Then
                        If y = 0 Then
                            If x = 0 Then
                                Me.bt0000.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0100.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0200.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0300.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0400.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0500.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0600.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0700.BackColor = glowColor
                            End If
                        ElseIf y = 1 Then
                            If x = 0 Then
                                Me.bt0001.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0101.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0201.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0301.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0401.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0501.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0601.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0701.BackColor = glowColor
                            End If
                        ElseIf y = 2 Then
                            If x = 0 Then
                                Me.bt0002.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0102.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0202.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0302.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0402.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0502.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0602.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0702.BackColor = glowColor
                            End If
                        ElseIf y = 3 Then
                            If x = 0 Then
                                Me.bt0003.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0103.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0203.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0303.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0403.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0503.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0603.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0703.BackColor = glowColor
                            End If
                        ElseIf y = 4 Then
                            If x = 0 Then
                                Me.bt0004.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0104.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0204.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0304.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0404.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0504.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0604.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0704.BackColor = glowColor
                            End If
                        ElseIf y = 5 Then
                            If x = 0 Then
                                Me.bt0005.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0105.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0205.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0305.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0405.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0505.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0605.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0705.BackColor = glowColor
                            End If
                        ElseIf y = 6 Then
                            If x = 0 Then
                                Me.bt0006.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0106.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0206.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0306.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0406.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0506.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0606.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0706.BackColor = glowColor
                            End If
                        ElseIf y = 7 Then
                            If x = 0 Then
                                Me.bt0007.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0107.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0207.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0307.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0407.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0507.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0607.BackColor = glowColor
                            ElseIf x = 7 Then
                                Me.bt0707.BackColor = glowColor
                            End If
                        End If
                    End If
                Next
            Next
        ElseIf turn = "B" And boardRotate = True Then
            For x As Integer = 0 To 7
                For y As Integer = 0 To 7
                    If selectable(x, y) = True Then
                        If y = 7 Then
                            If x = 7 Then
                                Me.bt0000.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0100.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0200.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0300.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0400.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0500.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0600.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0700.BackColor = glowColor
                            End If
                        ElseIf y = 6 Then
                            If x = 7 Then
                                Me.bt0001.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0101.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0201.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0301.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0401.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0501.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0601.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0701.BackColor = glowColor
                            End If
                        ElseIf y = 5 Then
                            If x = 7 Then
                                Me.bt0002.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0102.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0202.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0302.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0402.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0502.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0602.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0702.BackColor = glowColor
                            End If
                        ElseIf y = 4 Then
                            If x = 7 Then
                                Me.bt0003.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0103.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0203.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0303.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0403.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0503.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0603.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0703.BackColor = glowColor
                            End If
                        ElseIf y = 3 Then
                            If x = 7 Then
                                Me.bt0004.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0104.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0204.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0304.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0404.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0504.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0604.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0704.BackColor = glowColor
                            End If
                        ElseIf y = 2 Then
                            If x = 7 Then
                                Me.bt0005.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0105.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0205.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0305.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0405.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0505.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0605.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0705.BackColor = glowColor
                            End If
                        ElseIf y = 1 Then
                            If x = 7 Then
                                Me.bt0006.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0106.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0206.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0306.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0406.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0506.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0606.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0706.BackColor = glowColor
                            End If
                        ElseIf y = 0 Then
                            If x = 7 Then
                                Me.bt0007.BackColor = glowColor
                            ElseIf x = 6 Then
                                Me.bt0107.BackColor = glowColor
                            ElseIf x = 5 Then
                                Me.bt0207.BackColor = glowColor
                            ElseIf x = 4 Then
                                Me.bt0307.BackColor = glowColor
                            ElseIf x = 3 Then
                                Me.bt0407.BackColor = glowColor
                            ElseIf x = 2 Then
                                Me.bt0507.BackColor = glowColor
                            ElseIf x = 1 Then
                                Me.bt0607.BackColor = glowColor
                            ElseIf x = 0 Then
                                Me.bt0707.BackColor = glowColor
                            End If
                        End If
                    End If
                Next
            Next
        End If
    End Sub
    Sub ResetSelection()
        For x As Integer = 0 To 7
            For y As Integer = 0 To 7
                selectable(x, y) = False
            Next
        Next
        Me.bt0000.BackColor = lightTile
        Me.bt0100.BackColor = darkTile
        Me.bt0200.BackColor = lightTile
        Me.bt0300.BackColor = darkTile
        Me.bt0400.BackColor = lightTile
        Me.bt0500.BackColor = darkTile
        Me.bt0600.BackColor = lightTile
        Me.bt0700.BackColor = darkTile
        Me.bt0001.BackColor = darkTile
        Me.bt0101.BackColor = lightTile
        Me.bt0201.BackColor = darkTile
        Me.bt0301.BackColor = lightTile
        Me.bt0401.BackColor = darkTile
        Me.bt0501.BackColor = lightTile
        Me.bt0601.BackColor = darkTile
        Me.bt0701.BackColor = lightTile
        Me.bt0002.BackColor = lightTile
        Me.bt0102.BackColor = darkTile
        Me.bt0202.BackColor = lightTile
        Me.bt0302.BackColor = darkTile
        Me.bt0402.BackColor = lightTile
        Me.bt0502.BackColor = darkTile
        Me.bt0602.BackColor = lightTile
        Me.bt0702.BackColor = darkTile
        Me.bt0003.BackColor = darkTile
        Me.bt0103.BackColor = lightTile
        Me.bt0203.BackColor = darkTile
        Me.bt0303.BackColor = lightTile
        Me.bt0403.BackColor = darkTile
        Me.bt0503.BackColor = lightTile
        Me.bt0603.BackColor = darkTile
        Me.bt0703.BackColor = lightTile
        Me.bt0004.BackColor = lightTile
        Me.bt0104.BackColor = darkTile
        Me.bt0204.BackColor = lightTile
        Me.bt0304.BackColor = darkTile
        Me.bt0404.BackColor = lightTile
        Me.bt0504.BackColor = darkTile
        Me.bt0604.BackColor = lightTile
        Me.bt0704.BackColor = darkTile
        Me.bt0005.BackColor = darkTile
        Me.bt0105.BackColor = lightTile
        Me.bt0205.BackColor = darkTile
        Me.bt0305.BackColor = lightTile
        Me.bt0405.BackColor = darkTile
        Me.bt0505.BackColor = lightTile
        Me.bt0605.BackColor = darkTile
        Me.bt0705.BackColor = lightTile
        Me.bt0006.BackColor = lightTile
        Me.bt0106.BackColor = darkTile
        Me.bt0206.BackColor = lightTile
        Me.bt0306.BackColor = darkTile
        Me.bt0406.BackColor = lightTile
        Me.bt0506.BackColor = darkTile
        Me.bt0606.BackColor = lightTile
        Me.bt0706.BackColor = darkTile
        Me.bt0007.BackColor = darkTile
        Me.bt0107.BackColor = lightTile
        Me.bt0207.BackColor = darkTile
        Me.bt0307.BackColor = lightTile
        Me.bt0407.BackColor = darkTile
        Me.bt0507.BackColor = lightTile
        Me.bt0607.BackColor = darkTile
        Me.bt0707.BackColor = lightTile
    End Sub
    Sub CheckForCheck()
        For x As Integer = 0 To 7 Step 1
            For y As Integer = 0 To 7 Step 1
                If board(x, y) <> Nothing Then
                    If board(x, y).Remove(1, 1) <> turn Then
                        Select Case board(x, y).Remove(0, 1)
                            Case "P"
                                Call PawnC4C(x, y)
                            Case "R"
                                Call RookC4C(x, y)
                            Case "N"
                                Call KnightC4C(x, y)
                            Case "B"
                                Call BishopC4C(x, y)
                            Case "Q"
                                Call RookC4C(x, y)
                                Call BishopC4C(x, y)
                            Case "K"
                                Call KingC4C(x, y)
                        End Select
                    End If
                End If
            Next
        Next
    End Sub
    Sub ResetC4C()
        For x As Integer = 0 To 7
            For y As Integer = 0 To 7
                linesofCheck(x, y) = False
            Next
        Next
    End Sub

    Sub PawnMove(ByVal clickedX As Integer, ByVal clickedY As Integer)
        Select Case turn
            Case "W"
                'Move one square up
                If PieceColor(board(clickedX, clickedY - 1)) = Color.DimGray Then
                    selectable(clickedX, clickedY - 1) = True
                End If
                'Move two up on first move
                If clickedY = 6 And board(clickedX, 4) = Nothing Then
                    selectable(clickedX, 4) = True
                End If
                'Kill (left)
                If clickedX <> 0 And clickedY <> 0 Then
                    If PieceColor(board(clickedX - 1, clickedY - 1)) = Color.Black Then
                        selectable(clickedX - 1, clickedY - 1) = True
                    End If
                End If
                'Kill (right)
                If clickedX <> 7 And clickedY <> 7 Then
                    If PieceColor(board(clickedX + 1, clickedY - 1)) = Color.Black Then
                        selectable(clickedX + 1, clickedY - 1) = True
                    End If
                End If
            Case "B"
                'Move one square down
                If PieceColor(board(clickedX, clickedY + 1)) = Color.DimGray Then
                    selectable(clickedX, clickedY + 1) = True
                End If
                'Move two down on first move
                If clickedY = 1 And board(clickedX, 3) = Nothing Then
                    selectable(clickedX, 3) = True
                End If
                'Kill (left)
                If clickedX <> 0 And clickedY <> 0 Then
                    If PieceColor(board(clickedX - 1, clickedY + 1)) = Color.White Then
                        selectable(clickedX - 1, clickedY + 1) = True
                    End If
                End If
                'Kill (right)
                If clickedX <> 7 And clickedY <> 7 Then
                    If PieceColor(board(clickedX + 1, clickedY + 1)) = Color.White Then
                        selectable(clickedX + 1, clickedY + 1) = True
                    End If
                End If
        End Select
    End Sub
    Sub RookMove(ByVal clickedX As Integer, ByVal clickedY As Integer, ByVal oppositeColor As Color)
        'Move left
        If clickedX <> 0 Then
            For x As Integer = (clickedX - 1) To 0 Step -1
                If PieceColor(board(x, clickedY)) = Color.DimGray Then
                    selectable(x, clickedY) = True
                ElseIf PieceColor(board(x, clickedY)) = oppositeColor Then
                    selectable(x, clickedY) = True
                    Exit For
                Else
                    Exit For
                End If
            Next
        End If
        'Move right
        If clickedX <> 7 Then
            For x As Integer = (clickedX + 1) To 7 Step 1
                If PieceColor(board(x, clickedY)) = Color.DimGray Then
                    selectable(x, clickedY) = True
                ElseIf PieceColor(board(x, clickedY)) = oppositeColor Then
                    selectable(x, clickedY) = True
                    Exit For
                Else
                    Exit For
                End If
            Next
        End If
        'Move up
        If clickedY <> 0 Then
            For y As Integer = (clickedY - 1) To 0 Step -1
                If PieceColor(board(clickedX, y)) = Color.DimGray Then
                    selectable(clickedX, y) = True
                ElseIf PieceColor(board(clickedX, y)) = oppositeColor Then
                    selectable(clickedX, y) = True
                    Exit For
                Else
                    Exit For
                End If
            Next
        End If
        'Move down
        If clickedY <> 7 Then
            For y As Integer = (clickedY + 1) To 7 Step 1
                If PieceColor(board(clickedX, y)) = Color.DimGray Then
                    selectable(clickedX, y) = True
                ElseIf PieceColor(board(clickedX, y)) = oppositeColor Then
                    selectable(clickedX, y) = True
                    Exit For
                Else
                    Exit For
                End If
            Next
        End If
    End Sub
    Sub KnightMove(ByVal clickedX As Integer, ByVal clickedY As Integer, ByVal myColor As Color)
        If clickedX >= 1 Then             '11 o'clock selection
            If clickedY >= 2 Then
                If PieceColor(board(clickedX - 1, clickedY - 2)) <> myColor Then
                    selectable(clickedX - 1, clickedY - 2) = True
                End If
            End If
            If clickedY <= 5 Then         '7 o'clock selection
                If PieceColor(board(clickedX - 1, clickedY + 2)) <> myColor Then
                    selectable(clickedX - 1, clickedY + 2) = True
                End If
            End If
        End If
        If clickedX >= 2 Then
            If clickedY >= 1 Then         '10 o'clock selection
                If PieceColor(board(clickedX - 2, clickedY - 1)) <> myColor Then
                    selectable(clickedX - 2, clickedY - 1) = True
                End If
            End If
            If clickedY <= 6 Then         '8 o'clock selection
                If PieceColor(board(clickedX - 2, clickedY + 1)) <> myColor Then
                    selectable(clickedX - 2, clickedY + 1) = True
                End If
            End If
        End If
        If clickedX <= 6 Then             '1 o'clock selection
            If clickedY >= 2 Then
                If PieceColor(board(clickedX + 1, clickedY - 2)) <> myColor Then
                    selectable(clickedX + 1, clickedY - 2) = True
                End If
            End If
            If clickedY <= 5 Then         '5 o'clock selection
                If PieceColor(board(clickedX + 1, clickedY + 2)) <> myColor Then
                    selectable(clickedX + 1, clickedY + 2) = True
                End If
            End If
        End If
        If clickedX <= 5 Then
            If clickedY >= 1 Then         '2 o'clock selection
                If PieceColor(board(clickedX + 2, clickedY - 1)) <> myColor Then
                    selectable(clickedX + 2, clickedY - 1) = True
                End If
            End If
            If clickedY <= 6 Then         '4 o'clock selection
                If PieceColor(board(clickedX + 2, clickedY + 1)) <> myColor Then
                    selectable(clickedX + 2, clickedY + 1) = True
                End If
            End If
        End If
    End Sub
    Sub BishopMove(ByVal clickedX As Integer, ByVal clickedY As Integer, ByVal oppositeColor As Color)
        'Move up left
        If clickedX <> 0 And clickedY <> 0 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX - i >= 0 And clickedY - i >= 0 Then
                    If PieceColor(board(clickedX - i, clickedY - i)) = Color.DimGray Then
                        selectable(clickedX - i, clickedY - i) = True
                    ElseIf PieceColor(board(clickedX - i, clickedY - i)) = oppositeColor Then
                        selectable(clickedX - i, clickedY - i) = True
                        Exit For
                    Else
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move up right
        If clickedX <> 7 And clickedY <> 0 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX + i <= 7 And clickedY - i >= 0 Then
                    If PieceColor(board(clickedX + i, clickedY - i)) = Color.DimGray Then
                        selectable(clickedX + i, clickedY - i) = True
                    ElseIf PieceColor(board(clickedX + i, clickedY - i)) = oppositeColor Then
                        selectable(clickedX + i, clickedY - i) = True
                        Exit For
                    Else
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move down left
        If clickedX <> 0 And clickedY <> 7 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX - i >= 0 And clickedY + i <= 7 Then
                    If PieceColor(board(clickedX - i, clickedY + i)) = Color.DimGray Then
                        selectable(clickedX - i, clickedY + i) = True
                    ElseIf PieceColor(board(clickedX - i, clickedY + i)) = oppositeColor Then
                        selectable(clickedX - i, clickedY + i) = True
                        Exit For
                    Else
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move down right
        If clickedX <> 7 And clickedY <> 7 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX + i <= 7 And clickedY + i <= 7 Then
                    If PieceColor(board(clickedX + i, clickedY + i)) = Color.DimGray Then
                        selectable(clickedX + i, clickedY + i) = True
                    ElseIf PieceColor(board(clickedX + i, clickedY + i)) = oppositeColor Then
                        selectable(clickedX + i, clickedY + i) = True
                        Exit For
                    Else
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
    End Sub
    Sub KingMove(ByVal clickedX As Integer, ByVal clickedY As Integer, ByVal myColor As Color)
        If clickedX >= 1 Then
            If clickedY >= 1 Then
                If PieceColor(board(clickedX - 1, clickedY - 1)) <> myColor Then    'Top left
                    If linesofCheck(clickedX - 1, clickedY - 1) = False Then
                        selectable(clickedX - 1, clickedY - 1) = True
                    End If
                End If
            End If
            If clickedY <= 6 Then
                If PieceColor(board(clickedX - 1, clickedY + 1)) <> myColor Then    'Bottom left
                    If linesofCheck(clickedX - 1, clickedY + 1) = False Then
                        selectable(clickedX - 1, clickedY + 1) = True
                    End If
                End If
            End If
            If PieceColor(board(clickedX - 1, clickedY)) <> myColor Then            'Mid left
                If linesofCheck(clickedX - 1, clickedY) = False Then
                    selectable(clickedX - 1, clickedY) = True
                End If
            End If
        End If
        If clickedX <= 6 Then
            If clickedY >= 1 Then
                If PieceColor(board(clickedX + 1, clickedY - 1)) <> myColor Then    'Top right
                    If linesofCheck(clickedX + 1, clickedY - 1) = False Then
                        selectable(clickedX + 1, clickedY - 1) = True
                    End If
                End If
            End If
            If clickedY <= 6 Then
                If PieceColor(board(clickedX + 1, clickedY + 1)) <> myColor Then    'Bottom right
                    If linesofCheck(clickedX + 1, clickedY + 1) = False Then
                        selectable(clickedX + 1, clickedY + 1) = True
                    End If
                End If
            End If
            If PieceColor(board(clickedX + 1, clickedY)) <> myColor Then            'Mid right
                If linesofCheck(clickedX + 1, clickedY) = False Then
                    selectable(clickedX + 1, clickedY) = True
                End If
            End If
        End If
        If clickedY >= 1 Then
            If PieceColor(board(clickedX, clickedY - 1)) <> myColor Then            'Top mid
                If linesofCheck(clickedX, clickedY - 1) = False Then
                    selectable(clickedX, clickedY - 1) = True
                End If
            End If
        End If
        If clickedY <= 6 Then
            If PieceColor(board(clickedX, clickedY + 1)) <> myColor Then            'Bottom mid
                If linesofCheck(clickedX, clickedY + 1) = False Then
                    selectable(clickedX, clickedY + 1) = True
                End If
            End If
        End If
        'CASTLING
        Select Case turn
            Case "W"                                'For white
                If WKCastle = True Then                                                     'Kingside
                    If (board(5, 7) = Nothing) And (board(6, 7) = Nothing) Then
                        If linesofCheck(5, 7) = False And linesofCheck(6, 7) = False Then
                            selectable(6, 7) = True
                        End If
                    End If
                End If
                If WQCastle = True Then                                                     'Queenside
                    If (board(3, 7) = Nothing) And (board(2, 7) = Nothing) And (board(1, 7) = Nothing) Then
                        If linesofCheck(3, 7) = False And linesofCheck(2, 7) = False Then
                            selectable(2, 7) = True
                        End If
                    End If
                End If
            Case "B"                                'For black
                If BKCastle = True Then                                                     'Kingside
                    If (board(5, 0) = Nothing) And (board(6, 0) = Nothing) Then
                        If linesofCheck(5, 0) = False And linesofCheck(6, 0) = False Then
                            selectable(6, 0) = True
                        End If
                    End If
                End If
                If BQCastle = True Then                                                     'Queenside
                    If (board(3, 0) = Nothing) And (board(2, 0) = Nothing) And (board(1, 0) = Nothing) Then
                        If linesofCheck(3, 0) = False And linesofCheck(2, 0) = False Then
                            selectable(2, 0) = True
                        End If
                    End If
                End If
        End Select
    End Sub
    Sub PromotePawn()
        For x As Integer = 0 To 7
            If board(x, 0) = "WP" Then
                Dim promotePawn As String = InputBox("Which piece would you like to promote to?" & vbCrLf & _
                                                     "Type 'R' for rook" & vbCrLf & "Type 'N' for knight" & _
                                                     vbCrLf & "Type 'B' for bishop" & vbCrLf & "Type 'Q' for queen" _
                                                     & vbCrLf & vbCrLf & "Default is 'Q'", "Chess", "Q").ToUpper
                Select Case promotePawn.Chars(0)
                    Case "R"
                        board(x, 0) = "WR"
                    Case "N"
                        board(x, 0) = "WN"
                    Case "B"
                        board(x, 0) = "WB"
                    Case Else
                        board(x, 0) = "WQ"
                End Select
            End If
            If board(x, 7) = "BP" Then
                Dim promotePawn As String = InputBox("Which piece would you like to promote to?" & vbCrLf & _
                                                     "Type 'R' for rook" & vbCrLf & "Type 'N' for knight" & _
                                                     vbCrLf & "Type 'B' for bishop" & vbCrLf & "Type 'Q' for queen" _
                                                     & vbCrLf & vbCrLf & "Default is 'Q'", "Chess", "Q").ToUpper
                Select Case promotePawn.Chars(0)
                    Case "R"
                        board(x, 7) = "BR"
                    Case "N"
                        board(x, 7) = "BN"
                    Case "B"
                        board(x, 7) = "BB"
                    Case Else
                        board(x, 7) = "BQ"
                End Select
            End If
        Next
    End Sub

    Sub PawnC4C(ByVal clickedX As Integer, ByVal clickedY As Integer)
        Select Case turn
            Case "B"
                If clickedY <> 0 Then
                    'Kill (left)
                    If clickedX <> 0 And clickedY <> 0 Then
                        linesofCheck(clickedX - 1, clickedY - 1) = True
                    End If
                    'Kill (right)
                    If clickedX <> 7 And clickedY <> 7 Then
                        linesofCheck(clickedX + 1, clickedY - 1) = True
                    End If
                End If
            Case "W"
                If clickedY <> 7 Then
                    'Kill (left)
                    If clickedX <> 0 And clickedY <> 0 Then
                        linesofCheck(clickedX - 1, clickedY + 1) = True
                    End If
                    'Kill (right)
                    If clickedX <> 7 And clickedY <> 7 Then
                        linesofCheck(clickedX + 1, clickedY + 1) = True
                    End If
                End If
        End Select
    End Sub
    Sub RookC4C(ByVal clickedX As Integer, ByVal clickedY As Integer)
        'Move left
        If clickedX <> 0 Then
            For x As Integer = (clickedX - 1) To 0 Step -1
                If PieceColor(board(x, clickedY)) = Color.DimGray Then
                    linesofCheck(x, clickedY) = True
                Else
                    linesofCheck(x, clickedY) = True
                    Exit For
                End If
            Next
        End If
        'Move right
        If clickedX <> 7 Then
            For x As Integer = (clickedX + 1) To 7 Step 1
                If PieceColor(board(x, clickedY)) = Color.DimGray Then
                    linesofCheck(x, clickedY) = True
                Else
                    linesofCheck(x, clickedY) = True
                    Exit For
                End If
            Next
        End If
        'Move up
        If clickedY <> 0 Then
            For y As Integer = (clickedY - 1) To 0 Step -1
                If PieceColor(board(clickedX, y)) = Color.DimGray Then
                    linesofCheck(clickedX, y) = True
                Else
                    linesofCheck(clickedX, y) = True
                    Exit For
                End If
            Next
        End If
        'Move down
        If clickedY <> 7 Then
            For y As Integer = (clickedY + 1) To 7 Step 1
                If PieceColor(board(clickedX, y)) = Color.DimGray Then
                    linesofCheck(clickedX, y) = True
                Else
                    linesofCheck(clickedX, y) = True
                    Exit For
                End If
            Next
        End If
    End Sub
    Sub KnightC4C(ByVal clickedX As Integer, ByVal clickedY As Integer)
        If clickedX >= 1 Then             '11 o'clock selection
            If clickedY >= 2 Then
                linesofCheck(clickedX - 1, clickedY - 2) = True
            End If
            If clickedY <= 5 Then         '7 o'clock selection
                linesofCheck(clickedX - 1, clickedY + 2) = True
            End If
        End If
        If clickedX >= 2 Then
            If clickedY >= 1 Then         '10 o'clock selection
                linesofCheck(clickedX - 2, clickedY - 1) = True
            End If
            If clickedY <= 6 Then         '8 o'clock selection
                linesofCheck(clickedX - 2, clickedY + 1) = True
            End If
        End If
        If clickedX <= 6 Then             '1 o'clock selection
            If clickedY >= 2 Then
                linesofCheck(clickedX + 1, clickedY - 2) = True
            End If
            If clickedY <= 5 Then         '5 o'clock selection
                linesofCheck(clickedX + 1, clickedY + 2) = True
            End If
        End If
        If clickedX <= 5 Then
            If clickedY >= 1 Then         '2 o'clock selection
                linesofCheck(clickedX + 2, clickedY - 1) = True
            End If
            If clickedY <= 6 Then         '4 o'clock selection
                linesofCheck(clickedX + 2, clickedY + 1) = True
            End If
        End If
    End Sub
    Sub BishopC4C(ByVal clickedX As Integer, ByVal clickedY As Integer)
        'Move up left
        If clickedX <> 0 And clickedY <> 0 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX - i >= 0 And clickedY - i >= 0 Then
                    If PieceColor(board(clickedX - i, clickedY - i)) = Color.DimGray Then
                        linesofCheck(clickedX - i, clickedY - i) = True
                    Else
                        linesofCheck(clickedX - i, clickedY - i) = True
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move up right
        If clickedX <> 7 And clickedY <> 0 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX + i <= 7 And clickedY - i >= 0 Then
                    If PieceColor(board(clickedX + i, clickedY - i)) = Color.DimGray Then
                        linesofCheck(clickedX + i, clickedY - i) = True
                    Else
                        linesofCheck(clickedX + i, clickedY - i) = True
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move down left
        If clickedX <> 0 And clickedY <> 7 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX - i >= 0 And clickedY + i <= 7 Then
                    If PieceColor(board(clickedX - i, clickedY + i)) = Color.DimGray Then
                        linesofCheck(clickedX - i, clickedY + i) = True
                    Else
                        linesofCheck(clickedX - i, clickedY + i) = True
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
        'Move down right
        If clickedX <> 7 And clickedY <> 7 Then
            For i As Integer = 1 To 7 Step 1
                If clickedX + i <= 7 And clickedY + i <= 7 Then
                    If PieceColor(board(clickedX + i, clickedY + i)) = Color.DimGray Then
                        linesofCheck(clickedX + i, clickedY + i) = True
                    Else
                        linesofCheck(clickedX + i, clickedY + i) = True
                        Exit For
                    End If
                Else
                    Exit For
                End If
            Next
        End If
    End Sub
    Sub KingC4C(ByVal clickedX As Integer, ByVal clickedY As Integer)
        If clickedX >= 1 Then
            If clickedY >= 1 Then
                If linesofCheck(clickedX - 1, clickedY - 1) = False Then    'Top left
                    selectable(clickedX - 1, clickedY - 1) = True
                End If
            End If
            If clickedY <= 6 Then
                If linesofCheck(clickedX - 1, clickedY + 1) = False Then    'Bottom left
                    selectable(clickedX - 1, clickedY + 1) = True
                End If
            End If
            If linesofCheck(clickedX - 1, clickedY) = False Then            'Mid left
                selectable(clickedX - 1, clickedY) = True
            End If
        End If
        If clickedX <= 6 Then
            If clickedY >= 1 Then
                If linesofCheck(clickedX + 1, clickedY - 1) = False Then    'Top right
                    selectable(clickedX + 1, clickedY - 1) = True
                End If
            End If
            If clickedY <= 6 Then
                If linesofCheck(clickedX + 1, clickedY + 1) = False Then    'Bottom right
                    selectable(clickedX + 1, clickedY + 1) = True
                End If
            End If
            If linesofCheck(clickedX + 1, clickedY) = False Then            'Mid right
                selectable(clickedX + 1, clickedY) = True
            End If
        End If
        If clickedY >= 1 Then
            If linesofCheck(clickedX, clickedY - 1) = False Then            'Top mid
                selectable(clickedX, clickedY - 1) = True
            End If
        End If
        If clickedY <= 6 Then
            If linesofCheck(clickedX, clickedY + 1) = False Then            'Bottom mid
                selectable(clickedX, clickedY + 1) = True
            End If
        End If
    End Sub

    Private Sub CurrentScore(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CurrentScoreToolStripMenuItem.Click
        Dim wScore As Integer = 39
        Dim bScore As Integer = 39
        For x As Integer = 0 To 7
            For y As Integer = 0 To 7
                If board(x, y) <> Nothing Then
                    If board(x, y).Remove(1, 1) = "W" Then
                        Select Case board(x, y).Remove(0, 1)
                            Case "P"
                                bScore -= 1
                            Case "R"
                                bScore -= 5
                            Case "N", "B"
                                bScore -= 3
                            Case "Q"
                                bScore -= 9
                        End Select
                    ElseIf board(x, y).Remove(1, 1) = "B" Then
                        Select Case board(x, y).Remove(0, 1)
                            Case "P"
                                wScore -= 1
                            Case "R"
                                wScore -= 5
                            Case "N", "B"
                                wScore -= 3
                            Case "Q"
                                wScore -= 9
                        End Select
                    End If
                End If
            Next
        Next
        MessageBox.Show("White's score: " & wScore & vbCrLf & "Black's score: " & bScore, "Chess")
    End Sub

    Private Sub RoyalBlueGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RoyalBluedefaultToolStripMenuItem.Click
        glowColor = Color.RoyalBlue
    End Sub
    Private Sub CyanGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CyanToolStripMenuItem.Click
        glowColor = Color.Cyan
    End Sub
    Private Sub DarkKhakiGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DarkKhakiToolStripMenuItem.Click
        glowColor = Color.DarkKhaki
    End Sub
    Private Sub HotPinkGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HotPinkToolStripMenuItem.Click
        glowColor = Color.HotPink
    End Sub
    Private Sub LimeGreenGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LimeGreenToolStripMenuItem.Click
        glowColor = Color.LimeGreen
    End Sub
    Private Sub RedGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RedToolStripMenuItem.Click
        glowColor = Color.Red
    End Sub
    Private Sub SilverGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SilverToolStripMenuItem.Click
        glowColor = Color.Silver
    End Sub
    Private Sub YellowGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles YellowToolStripMenuItem.Click
        glowColor = Color.Yellow
    End Sub

    Private Sub ClassicBoard(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClassicToolStripMenuItem.Click
        lightTile = Color.SandyBrown
        darkTile = Color.SaddleBrown
        Call ResetSelection()
    End Sub
    Private Sub BlackAndWhiteBoard(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackWhiteToolStripMenuItem.Click
        lightTile = Color.Gainsboro
        darkTile = Color.Gray
        Call ResetSelection()
    End Sub
    Private Sub EricBoard(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EricsCustomColorToolStripMenuItem.Click
        lightTile = Color.Fuchsia
        darkTile = Color.MediumSeaGreen
        Call ResetSelection()
    End Sub
    Private Sub RolloutBoard(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RolloutBoardToolStripMenuItem.Click
        lightTile = Color.LightGray
        darkTile = Color.Green
        Call ResetSelection()
    End Sub

    Private Sub OneSecondPasses(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmOneSecond.Tick
        If turn = "W" Then
            wTimeS -= 1
            If wTimeS < 0 Then
                wTimeM -= 1
                If wTimeM >= 0 Then
                    wTimeS = 59
                End If
            End If
        ElseIf turn = "B" Then
            bTimeS -= 1
            If bTimeS < 0 Then
                bTimeM -= 1
                If bTimeM >= 0 Then
                    bTimeS = 59
                End If
            End If
        End If
        Call UpdateTimers()
    End Sub
    Sub UpdateTimers()
        If turn = "W" Or boardRotate = False Then
            Me.btBottomTime.Text = Format(wTimeM, "##") & ":" & Format(wTimeS, "##")
            If wTimeS = 0 Then
                Me.btBottomTime.Text &= "00"
            End If
            Me.btTopTime.Text = Format(bTimeM, "##") & ":" & Format(bTimeS, "##")
            If bTimeS = 0 Then
                Me.btTopTime.Text &= "00"
            End If
            Me.btBottomTime.Enabled = True
        ElseIf turn = "B" And boardRotate = True Then
            Me.btBottomTime.Text = Format(bTimeM, "##") & ":" & Format(bTimeS, "##")
            If bTimeS = 0 Then
                Me.btBottomTime.Text &= "00"
            End If
            Me.btTopTime.Text = Format(wTimeM, "##") & ":" & Format(wTimeS, "##")
            If wTimeS = 0 Then
                Me.btTopTime.Text &= "00"
            End If
        End If
        If timersOn = True Then
            If turn = "B" And boardRotate = False Then
                Me.btBottomTime.Enabled = False
                Me.btTopTime.Enabled = True
            ElseIf turn = "W" And boardRotate = False Then
                Me.btTopTime.Enabled = False
                Me.btBottomTime.Enabled = True
            End If
        End If
    End Sub

    Private Sub TwoMinTime(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        timersOn = True
        wTimeM = 2
        bTimeM = 2
        wTimeS = 0
        bTimeS = 0
        tmOneSecond.Stop()
        tmOneSecond.Start()
        Call UpdateTimers()
    End Sub
    Private Sub FiveMinTime(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        timersOn = True
        wTimeM = 5
        bTimeM = 5
        wTimeS = 0
        bTimeS = 0
        tmOneSecond.Stop()
        tmOneSecond.Start()
        Call UpdateTimers()
    End Sub
    Private Sub TenMinTime(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click
        timersOn = True
        wTimeM = 10
        bTimeM = 10
        wTimeS = 0
        bTimeS = 0
        tmOneSecond.Stop()
        tmOneSecond.Start()
        Call UpdateTimers()
    End Sub
    Private Sub TwentyMinTime(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem6.Click
        timersOn = True
        wTimeM = 20
        bTimeM = 20
        wTimeS = 0
        bTimeS = 0
        tmOneSecond.Stop()
        tmOneSecond.Start()
        Call UpdateTimers()
    End Sub
    Private Sub ThirtyMinTime(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click
        timersOn = True
        wTimeM = 30
        bTimeM = 30
        wTimeS = 0
        bTimeS = 0
        tmOneSecond.Stop()
        tmOneSecond.Start()
        Call UpdateTimers()
    End Sub
    Private Sub RemoveTimer(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveTimerToolStripMenuItem.Click
        timersOn = False
        tmOneSecond.Stop()
        wTimeM = 0
        bTimeM = 0
        wTimeS = 0
        bTimeS = 0
        Me.btBottomTime.Text = "--:--"
        Me.btTopTime.Text = "--:--"
        Me.btBottomTime.Enabled = False
        Me.btTopTime.Enabled = False
    End Sub

    Private Sub BoardRotateToggled(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotateBoardToolStripMenuItem.Click
        If boardRotate = True Then
            boardRotate = False
        Else
            boardRotate = True
        End If
        Call UpdateBoard()
        Call ResetSelection()
        If timersOn = True Then
            Call UpdateTimers()
        End If
    End Sub

    Private Sub Credits(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreditsToolStripMenuItem.Click
        MessageBox.Show("Game and code entirely created from scratch by Leonardo Gama", "Credits")
        MessageBox.Show("Special thanks to Eric Tran for custom boards and being annoying", "Credits")
        MessageBox.Show("Also giving me extra work :/", "Credits")
        MessageBox.Show("RIP bonus marks :'((", "Credits")
    End Sub

    Private Sub CustomColorGlow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomColorToolStripMenuItem.Click
        Me.cdMoveGlow.ShowDialog()
        glowColor = Me.cdMoveGlow.Color
    End Sub
    Private Sub CustomBoard(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomBoardToolStripMenuItem.Click
        MessageBox.Show("Select a light square color", "Chess")
        Me.cdLightSquare.ShowDialog()
        MessageBox.Show("Select a dark square color", "Chess")
        Me.cdDarkSquare.ShowDialog()
        lightTile = Me.cdLightSquare.Color
        darkTile = Me.cdDarkSquare.Color
        Call ResetSelection()
    End Sub
End Class