﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fmChess
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.bt0000 = New System.Windows.Forms.Button
        Me.bt0100 = New System.Windows.Forms.Button
        Me.bt0200 = New System.Windows.Forms.Button
        Me.bt0300 = New System.Windows.Forms.Button
        Me.bt0400 = New System.Windows.Forms.Button
        Me.bt0500 = New System.Windows.Forms.Button
        Me.bt0600 = New System.Windows.Forms.Button
        Me.bt0700 = New System.Windows.Forms.Button
        Me.bt0701 = New System.Windows.Forms.Button
        Me.bt0601 = New System.Windows.Forms.Button
        Me.bt0501 = New System.Windows.Forms.Button
        Me.bt0401 = New System.Windows.Forms.Button
        Me.bt0301 = New System.Windows.Forms.Button
        Me.bt0201 = New System.Windows.Forms.Button
        Me.bt0101 = New System.Windows.Forms.Button
        Me.bt0001 = New System.Windows.Forms.Button
        Me.bt0702 = New System.Windows.Forms.Button
        Me.bt0602 = New System.Windows.Forms.Button
        Me.bt0502 = New System.Windows.Forms.Button
        Me.bt0402 = New System.Windows.Forms.Button
        Me.bt0302 = New System.Windows.Forms.Button
        Me.bt0202 = New System.Windows.Forms.Button
        Me.bt0102 = New System.Windows.Forms.Button
        Me.bt0002 = New System.Windows.Forms.Button
        Me.bt0703 = New System.Windows.Forms.Button
        Me.bt0603 = New System.Windows.Forms.Button
        Me.bt0503 = New System.Windows.Forms.Button
        Me.bt0403 = New System.Windows.Forms.Button
        Me.bt0303 = New System.Windows.Forms.Button
        Me.bt0203 = New System.Windows.Forms.Button
        Me.bt0103 = New System.Windows.Forms.Button
        Me.bt0003 = New System.Windows.Forms.Button
        Me.bt0704 = New System.Windows.Forms.Button
        Me.bt0604 = New System.Windows.Forms.Button
        Me.bt0504 = New System.Windows.Forms.Button
        Me.bt0404 = New System.Windows.Forms.Button
        Me.bt0304 = New System.Windows.Forms.Button
        Me.bt0204 = New System.Windows.Forms.Button
        Me.bt0104 = New System.Windows.Forms.Button
        Me.bt0004 = New System.Windows.Forms.Button
        Me.bt0705 = New System.Windows.Forms.Button
        Me.bt0605 = New System.Windows.Forms.Button
        Me.bt0505 = New System.Windows.Forms.Button
        Me.bt0405 = New System.Windows.Forms.Button
        Me.bt0305 = New System.Windows.Forms.Button
        Me.bt0205 = New System.Windows.Forms.Button
        Me.bt0105 = New System.Windows.Forms.Button
        Me.bt0005 = New System.Windows.Forms.Button
        Me.bt0706 = New System.Windows.Forms.Button
        Me.bt0606 = New System.Windows.Forms.Button
        Me.bt0506 = New System.Windows.Forms.Button
        Me.bt0406 = New System.Windows.Forms.Button
        Me.bt0306 = New System.Windows.Forms.Button
        Me.bt0206 = New System.Windows.Forms.Button
        Me.bt0106 = New System.Windows.Forms.Button
        Me.bt0006 = New System.Windows.Forms.Button
        Me.bt0707 = New System.Windows.Forms.Button
        Me.bt0607 = New System.Windows.Forms.Button
        Me.bt0507 = New System.Windows.Forms.Button
        Me.bt0407 = New System.Windows.Forms.Button
        Me.bt0307 = New System.Windows.Forms.Button
        Me.bt0207 = New System.Windows.Forms.Button
        Me.bt0107 = New System.Windows.Forms.Button
        Me.bt0007 = New System.Windows.Forms.Button
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ChessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NewGameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CurrentScoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TimerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveTimerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeMoveGlowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RoyalBluedefaultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CyanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DarkKhakiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HotPinkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LimeGreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SilverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.YellowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeBoardColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClassicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BlackWhiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RolloutBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EricsCustomColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RotateBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreditsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.btTopTime = New System.Windows.Forms.Button
        Me.btBottomTime = New System.Windows.Forms.Button
        Me.tmOneSecond = New System.Windows.Forms.Timer(Me.components)
        Me.cdMoveGlow = New System.Windows.Forms.ColorDialog
        Me.cdDarkSquare = New System.Windows.Forms.ColorDialog
        Me.cdLightSquare = New System.Windows.Forms.ColorDialog
        Me.CustomBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'bt0000
        '
        Me.bt0000.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0000.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0000.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0000.ForeColor = System.Drawing.Color.DimGray
        Me.bt0000.Location = New System.Drawing.Point(12, 32)
        Me.bt0000.Name = "bt0000"
        Me.bt0000.Size = New System.Drawing.Size(36, 36)
        Me.bt0000.TabIndex = 0
        Me.bt0000.Tag = "0000"
        Me.bt0000.UseVisualStyleBackColor = False
        '
        'bt0100
        '
        Me.bt0100.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0100.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0100.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0100.ForeColor = System.Drawing.Color.DimGray
        Me.bt0100.Location = New System.Drawing.Point(48, 32)
        Me.bt0100.Name = "bt0100"
        Me.bt0100.Size = New System.Drawing.Size(36, 36)
        Me.bt0100.TabIndex = 1
        Me.bt0100.Tag = "0100"
        Me.bt0100.UseVisualStyleBackColor = False
        '
        'bt0200
        '
        Me.bt0200.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0200.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0200.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0200.ForeColor = System.Drawing.Color.DimGray
        Me.bt0200.Location = New System.Drawing.Point(84, 32)
        Me.bt0200.Name = "bt0200"
        Me.bt0200.Size = New System.Drawing.Size(36, 36)
        Me.bt0200.TabIndex = 2
        Me.bt0200.Tag = "0200"
        Me.bt0200.UseVisualStyleBackColor = False
        '
        'bt0300
        '
        Me.bt0300.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0300.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0300.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0300.ForeColor = System.Drawing.Color.DimGray
        Me.bt0300.Location = New System.Drawing.Point(120, 32)
        Me.bt0300.Name = "bt0300"
        Me.bt0300.Size = New System.Drawing.Size(36, 36)
        Me.bt0300.TabIndex = 3
        Me.bt0300.Tag = "0300"
        Me.bt0300.UseVisualStyleBackColor = False
        '
        'bt0400
        '
        Me.bt0400.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0400.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0400.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0400.ForeColor = System.Drawing.Color.DimGray
        Me.bt0400.Location = New System.Drawing.Point(156, 32)
        Me.bt0400.Name = "bt0400"
        Me.bt0400.Size = New System.Drawing.Size(36, 36)
        Me.bt0400.TabIndex = 4
        Me.bt0400.Tag = "0400"
        Me.bt0400.UseVisualStyleBackColor = False
        '
        'bt0500
        '
        Me.bt0500.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0500.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0500.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0500.ForeColor = System.Drawing.Color.DimGray
        Me.bt0500.Location = New System.Drawing.Point(192, 32)
        Me.bt0500.Name = "bt0500"
        Me.bt0500.Size = New System.Drawing.Size(36, 36)
        Me.bt0500.TabIndex = 5
        Me.bt0500.Tag = "0500"
        Me.bt0500.UseVisualStyleBackColor = False
        '
        'bt0600
        '
        Me.bt0600.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0600.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0600.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0600.ForeColor = System.Drawing.Color.DimGray
        Me.bt0600.Location = New System.Drawing.Point(228, 32)
        Me.bt0600.Name = "bt0600"
        Me.bt0600.Size = New System.Drawing.Size(36, 36)
        Me.bt0600.TabIndex = 6
        Me.bt0600.Tag = "0600"
        Me.bt0600.UseVisualStyleBackColor = False
        '
        'bt0700
        '
        Me.bt0700.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0700.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0700.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0700.ForeColor = System.Drawing.Color.DimGray
        Me.bt0700.Location = New System.Drawing.Point(264, 32)
        Me.bt0700.Name = "bt0700"
        Me.bt0700.Size = New System.Drawing.Size(36, 36)
        Me.bt0700.TabIndex = 7
        Me.bt0700.Tag = "0700"
        Me.bt0700.UseVisualStyleBackColor = False
        '
        'bt0701
        '
        Me.bt0701.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0701.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0701.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0701.ForeColor = System.Drawing.Color.DimGray
        Me.bt0701.Location = New System.Drawing.Point(264, 68)
        Me.bt0701.Name = "bt0701"
        Me.bt0701.Size = New System.Drawing.Size(36, 36)
        Me.bt0701.TabIndex = 15
        Me.bt0701.Tag = "0701"
        Me.bt0701.UseVisualStyleBackColor = False
        '
        'bt0601
        '
        Me.bt0601.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0601.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0601.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0601.ForeColor = System.Drawing.Color.DimGray
        Me.bt0601.Location = New System.Drawing.Point(228, 68)
        Me.bt0601.Name = "bt0601"
        Me.bt0601.Size = New System.Drawing.Size(36, 36)
        Me.bt0601.TabIndex = 14
        Me.bt0601.Tag = "0601"
        Me.bt0601.UseVisualStyleBackColor = False
        '
        'bt0501
        '
        Me.bt0501.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0501.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0501.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0501.ForeColor = System.Drawing.Color.DimGray
        Me.bt0501.Location = New System.Drawing.Point(192, 68)
        Me.bt0501.Name = "bt0501"
        Me.bt0501.Size = New System.Drawing.Size(36, 36)
        Me.bt0501.TabIndex = 13
        Me.bt0501.Tag = "0501"
        Me.bt0501.UseVisualStyleBackColor = False
        '
        'bt0401
        '
        Me.bt0401.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0401.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0401.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0401.ForeColor = System.Drawing.Color.DimGray
        Me.bt0401.Location = New System.Drawing.Point(156, 68)
        Me.bt0401.Name = "bt0401"
        Me.bt0401.Size = New System.Drawing.Size(36, 36)
        Me.bt0401.TabIndex = 12
        Me.bt0401.Tag = "0401"
        Me.bt0401.UseVisualStyleBackColor = False
        '
        'bt0301
        '
        Me.bt0301.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0301.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0301.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0301.ForeColor = System.Drawing.Color.DimGray
        Me.bt0301.Location = New System.Drawing.Point(120, 68)
        Me.bt0301.Name = "bt0301"
        Me.bt0301.Size = New System.Drawing.Size(36, 36)
        Me.bt0301.TabIndex = 11
        Me.bt0301.Tag = "0301"
        Me.bt0301.UseVisualStyleBackColor = False
        '
        'bt0201
        '
        Me.bt0201.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0201.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0201.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0201.ForeColor = System.Drawing.Color.DimGray
        Me.bt0201.Location = New System.Drawing.Point(84, 68)
        Me.bt0201.Name = "bt0201"
        Me.bt0201.Size = New System.Drawing.Size(36, 36)
        Me.bt0201.TabIndex = 10
        Me.bt0201.Tag = "0201"
        Me.bt0201.UseVisualStyleBackColor = False
        '
        'bt0101
        '
        Me.bt0101.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0101.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0101.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0101.ForeColor = System.Drawing.Color.DimGray
        Me.bt0101.Location = New System.Drawing.Point(48, 68)
        Me.bt0101.Name = "bt0101"
        Me.bt0101.Size = New System.Drawing.Size(36, 36)
        Me.bt0101.TabIndex = 9
        Me.bt0101.Tag = "0101"
        Me.bt0101.UseVisualStyleBackColor = False
        '
        'bt0001
        '
        Me.bt0001.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0001.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0001.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0001.ForeColor = System.Drawing.Color.DimGray
        Me.bt0001.Location = New System.Drawing.Point(12, 68)
        Me.bt0001.Name = "bt0001"
        Me.bt0001.Size = New System.Drawing.Size(36, 36)
        Me.bt0001.TabIndex = 8
        Me.bt0001.Tag = "0001"
        Me.bt0001.UseVisualStyleBackColor = False
        '
        'bt0702
        '
        Me.bt0702.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0702.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0702.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0702.ForeColor = System.Drawing.Color.DimGray
        Me.bt0702.Location = New System.Drawing.Point(264, 104)
        Me.bt0702.Name = "bt0702"
        Me.bt0702.Size = New System.Drawing.Size(36, 36)
        Me.bt0702.TabIndex = 23
        Me.bt0702.Tag = "0702"
        Me.bt0702.UseVisualStyleBackColor = False
        '
        'bt0602
        '
        Me.bt0602.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0602.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0602.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0602.ForeColor = System.Drawing.Color.DimGray
        Me.bt0602.Location = New System.Drawing.Point(228, 104)
        Me.bt0602.Name = "bt0602"
        Me.bt0602.Size = New System.Drawing.Size(36, 36)
        Me.bt0602.TabIndex = 22
        Me.bt0602.Tag = "0602"
        Me.bt0602.UseVisualStyleBackColor = False
        '
        'bt0502
        '
        Me.bt0502.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0502.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0502.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0502.ForeColor = System.Drawing.Color.DimGray
        Me.bt0502.Location = New System.Drawing.Point(192, 104)
        Me.bt0502.Name = "bt0502"
        Me.bt0502.Size = New System.Drawing.Size(36, 36)
        Me.bt0502.TabIndex = 21
        Me.bt0502.Tag = "0502"
        Me.bt0502.UseVisualStyleBackColor = False
        '
        'bt0402
        '
        Me.bt0402.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0402.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0402.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0402.ForeColor = System.Drawing.Color.DimGray
        Me.bt0402.Location = New System.Drawing.Point(156, 104)
        Me.bt0402.Name = "bt0402"
        Me.bt0402.Size = New System.Drawing.Size(36, 36)
        Me.bt0402.TabIndex = 20
        Me.bt0402.Tag = "0402"
        Me.bt0402.UseVisualStyleBackColor = False
        '
        'bt0302
        '
        Me.bt0302.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0302.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0302.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0302.ForeColor = System.Drawing.Color.DimGray
        Me.bt0302.Location = New System.Drawing.Point(120, 104)
        Me.bt0302.Name = "bt0302"
        Me.bt0302.Size = New System.Drawing.Size(36, 36)
        Me.bt0302.TabIndex = 19
        Me.bt0302.Tag = "0302"
        Me.bt0302.UseVisualStyleBackColor = False
        '
        'bt0202
        '
        Me.bt0202.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0202.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0202.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0202.ForeColor = System.Drawing.Color.DimGray
        Me.bt0202.Location = New System.Drawing.Point(84, 104)
        Me.bt0202.Name = "bt0202"
        Me.bt0202.Size = New System.Drawing.Size(36, 36)
        Me.bt0202.TabIndex = 18
        Me.bt0202.Tag = "0202"
        Me.bt0202.UseVisualStyleBackColor = False
        '
        'bt0102
        '
        Me.bt0102.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0102.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0102.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0102.ForeColor = System.Drawing.Color.DimGray
        Me.bt0102.Location = New System.Drawing.Point(48, 104)
        Me.bt0102.Name = "bt0102"
        Me.bt0102.Size = New System.Drawing.Size(36, 36)
        Me.bt0102.TabIndex = 17
        Me.bt0102.Tag = "0102"
        Me.bt0102.UseVisualStyleBackColor = False
        '
        'bt0002
        '
        Me.bt0002.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0002.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0002.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0002.ForeColor = System.Drawing.Color.DimGray
        Me.bt0002.Location = New System.Drawing.Point(12, 104)
        Me.bt0002.Name = "bt0002"
        Me.bt0002.Size = New System.Drawing.Size(36, 36)
        Me.bt0002.TabIndex = 16
        Me.bt0002.Tag = "0002"
        Me.bt0002.UseVisualStyleBackColor = False
        '
        'bt0703
        '
        Me.bt0703.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0703.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0703.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0703.ForeColor = System.Drawing.Color.DimGray
        Me.bt0703.Location = New System.Drawing.Point(264, 140)
        Me.bt0703.Name = "bt0703"
        Me.bt0703.Size = New System.Drawing.Size(36, 36)
        Me.bt0703.TabIndex = 31
        Me.bt0703.Tag = "0703"
        Me.bt0703.UseVisualStyleBackColor = False
        '
        'bt0603
        '
        Me.bt0603.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0603.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0603.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0603.ForeColor = System.Drawing.Color.DimGray
        Me.bt0603.Location = New System.Drawing.Point(228, 140)
        Me.bt0603.Name = "bt0603"
        Me.bt0603.Size = New System.Drawing.Size(36, 36)
        Me.bt0603.TabIndex = 30
        Me.bt0603.Tag = "0603"
        Me.bt0603.UseVisualStyleBackColor = False
        '
        'bt0503
        '
        Me.bt0503.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0503.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0503.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0503.ForeColor = System.Drawing.Color.DimGray
        Me.bt0503.Location = New System.Drawing.Point(192, 140)
        Me.bt0503.Name = "bt0503"
        Me.bt0503.Size = New System.Drawing.Size(36, 36)
        Me.bt0503.TabIndex = 29
        Me.bt0503.Tag = "0503"
        Me.bt0503.UseVisualStyleBackColor = False
        '
        'bt0403
        '
        Me.bt0403.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0403.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0403.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0403.ForeColor = System.Drawing.Color.DimGray
        Me.bt0403.Location = New System.Drawing.Point(156, 140)
        Me.bt0403.Name = "bt0403"
        Me.bt0403.Size = New System.Drawing.Size(36, 36)
        Me.bt0403.TabIndex = 28
        Me.bt0403.Tag = "0403"
        Me.bt0403.UseVisualStyleBackColor = False
        '
        'bt0303
        '
        Me.bt0303.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0303.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0303.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0303.ForeColor = System.Drawing.Color.DimGray
        Me.bt0303.Location = New System.Drawing.Point(120, 140)
        Me.bt0303.Name = "bt0303"
        Me.bt0303.Size = New System.Drawing.Size(36, 36)
        Me.bt0303.TabIndex = 27
        Me.bt0303.Tag = "0303"
        Me.bt0303.UseVisualStyleBackColor = False
        '
        'bt0203
        '
        Me.bt0203.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0203.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0203.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0203.ForeColor = System.Drawing.Color.DimGray
        Me.bt0203.Location = New System.Drawing.Point(84, 140)
        Me.bt0203.Name = "bt0203"
        Me.bt0203.Size = New System.Drawing.Size(36, 36)
        Me.bt0203.TabIndex = 26
        Me.bt0203.Tag = "0203"
        Me.bt0203.UseVisualStyleBackColor = False
        '
        'bt0103
        '
        Me.bt0103.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0103.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0103.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0103.ForeColor = System.Drawing.Color.DimGray
        Me.bt0103.Location = New System.Drawing.Point(48, 140)
        Me.bt0103.Name = "bt0103"
        Me.bt0103.Size = New System.Drawing.Size(36, 36)
        Me.bt0103.TabIndex = 25
        Me.bt0103.Tag = "0103"
        Me.bt0103.UseVisualStyleBackColor = False
        '
        'bt0003
        '
        Me.bt0003.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0003.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0003.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0003.ForeColor = System.Drawing.Color.DimGray
        Me.bt0003.Location = New System.Drawing.Point(12, 140)
        Me.bt0003.Name = "bt0003"
        Me.bt0003.Size = New System.Drawing.Size(36, 36)
        Me.bt0003.TabIndex = 24
        Me.bt0003.Tag = "0003"
        Me.bt0003.UseVisualStyleBackColor = False
        '
        'bt0704
        '
        Me.bt0704.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0704.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0704.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0704.ForeColor = System.Drawing.Color.DimGray
        Me.bt0704.Location = New System.Drawing.Point(264, 176)
        Me.bt0704.Name = "bt0704"
        Me.bt0704.Size = New System.Drawing.Size(36, 36)
        Me.bt0704.TabIndex = 39
        Me.bt0704.Tag = "0704"
        Me.bt0704.UseVisualStyleBackColor = False
        '
        'bt0604
        '
        Me.bt0604.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0604.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0604.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0604.ForeColor = System.Drawing.Color.DimGray
        Me.bt0604.Location = New System.Drawing.Point(228, 176)
        Me.bt0604.Name = "bt0604"
        Me.bt0604.Size = New System.Drawing.Size(36, 36)
        Me.bt0604.TabIndex = 38
        Me.bt0604.Tag = "0604"
        Me.bt0604.UseVisualStyleBackColor = False
        '
        'bt0504
        '
        Me.bt0504.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0504.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0504.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0504.ForeColor = System.Drawing.Color.DimGray
        Me.bt0504.Location = New System.Drawing.Point(192, 176)
        Me.bt0504.Name = "bt0504"
        Me.bt0504.Size = New System.Drawing.Size(36, 36)
        Me.bt0504.TabIndex = 37
        Me.bt0504.Tag = "0504"
        Me.bt0504.UseVisualStyleBackColor = False
        '
        'bt0404
        '
        Me.bt0404.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0404.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0404.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0404.ForeColor = System.Drawing.Color.DimGray
        Me.bt0404.Location = New System.Drawing.Point(156, 176)
        Me.bt0404.Name = "bt0404"
        Me.bt0404.Size = New System.Drawing.Size(36, 36)
        Me.bt0404.TabIndex = 36
        Me.bt0404.Tag = "0404"
        Me.bt0404.UseVisualStyleBackColor = False
        '
        'bt0304
        '
        Me.bt0304.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0304.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0304.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0304.ForeColor = System.Drawing.Color.DimGray
        Me.bt0304.Location = New System.Drawing.Point(120, 176)
        Me.bt0304.Name = "bt0304"
        Me.bt0304.Size = New System.Drawing.Size(36, 36)
        Me.bt0304.TabIndex = 35
        Me.bt0304.Tag = "0304"
        Me.bt0304.UseVisualStyleBackColor = False
        '
        'bt0204
        '
        Me.bt0204.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0204.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0204.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0204.ForeColor = System.Drawing.Color.DimGray
        Me.bt0204.Location = New System.Drawing.Point(84, 176)
        Me.bt0204.Name = "bt0204"
        Me.bt0204.Size = New System.Drawing.Size(36, 36)
        Me.bt0204.TabIndex = 34
        Me.bt0204.Tag = "0204"
        Me.bt0204.UseVisualStyleBackColor = False
        '
        'bt0104
        '
        Me.bt0104.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0104.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0104.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0104.ForeColor = System.Drawing.Color.DimGray
        Me.bt0104.Location = New System.Drawing.Point(48, 176)
        Me.bt0104.Name = "bt0104"
        Me.bt0104.Size = New System.Drawing.Size(36, 36)
        Me.bt0104.TabIndex = 33
        Me.bt0104.Tag = "0104"
        Me.bt0104.UseVisualStyleBackColor = False
        '
        'bt0004
        '
        Me.bt0004.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0004.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0004.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0004.ForeColor = System.Drawing.Color.DimGray
        Me.bt0004.Location = New System.Drawing.Point(12, 176)
        Me.bt0004.Name = "bt0004"
        Me.bt0004.Size = New System.Drawing.Size(36, 36)
        Me.bt0004.TabIndex = 32
        Me.bt0004.Tag = "0004"
        Me.bt0004.UseVisualStyleBackColor = False
        '
        'bt0705
        '
        Me.bt0705.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0705.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0705.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0705.ForeColor = System.Drawing.Color.DimGray
        Me.bt0705.Location = New System.Drawing.Point(264, 212)
        Me.bt0705.Name = "bt0705"
        Me.bt0705.Size = New System.Drawing.Size(36, 36)
        Me.bt0705.TabIndex = 47
        Me.bt0705.Tag = "0705"
        Me.bt0705.UseVisualStyleBackColor = False
        '
        'bt0605
        '
        Me.bt0605.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0605.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0605.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0605.ForeColor = System.Drawing.Color.DimGray
        Me.bt0605.Location = New System.Drawing.Point(228, 212)
        Me.bt0605.Name = "bt0605"
        Me.bt0605.Size = New System.Drawing.Size(36, 36)
        Me.bt0605.TabIndex = 46
        Me.bt0605.Tag = "0605"
        Me.bt0605.UseVisualStyleBackColor = False
        '
        'bt0505
        '
        Me.bt0505.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0505.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0505.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0505.ForeColor = System.Drawing.Color.DimGray
        Me.bt0505.Location = New System.Drawing.Point(192, 212)
        Me.bt0505.Name = "bt0505"
        Me.bt0505.Size = New System.Drawing.Size(36, 36)
        Me.bt0505.TabIndex = 45
        Me.bt0505.Tag = "0505"
        Me.bt0505.UseVisualStyleBackColor = False
        '
        'bt0405
        '
        Me.bt0405.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0405.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0405.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0405.ForeColor = System.Drawing.Color.DimGray
        Me.bt0405.Location = New System.Drawing.Point(156, 212)
        Me.bt0405.Name = "bt0405"
        Me.bt0405.Size = New System.Drawing.Size(36, 36)
        Me.bt0405.TabIndex = 44
        Me.bt0405.Tag = "0405"
        Me.bt0405.UseVisualStyleBackColor = False
        '
        'bt0305
        '
        Me.bt0305.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0305.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0305.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0305.ForeColor = System.Drawing.Color.DimGray
        Me.bt0305.Location = New System.Drawing.Point(120, 212)
        Me.bt0305.Name = "bt0305"
        Me.bt0305.Size = New System.Drawing.Size(36, 36)
        Me.bt0305.TabIndex = 43
        Me.bt0305.Tag = "0305"
        Me.bt0305.UseVisualStyleBackColor = False
        '
        'bt0205
        '
        Me.bt0205.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0205.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0205.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0205.ForeColor = System.Drawing.Color.DimGray
        Me.bt0205.Location = New System.Drawing.Point(84, 212)
        Me.bt0205.Name = "bt0205"
        Me.bt0205.Size = New System.Drawing.Size(36, 36)
        Me.bt0205.TabIndex = 42
        Me.bt0205.Tag = "0205"
        Me.bt0205.UseVisualStyleBackColor = False
        '
        'bt0105
        '
        Me.bt0105.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0105.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0105.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0105.ForeColor = System.Drawing.Color.DimGray
        Me.bt0105.Location = New System.Drawing.Point(48, 212)
        Me.bt0105.Name = "bt0105"
        Me.bt0105.Size = New System.Drawing.Size(36, 36)
        Me.bt0105.TabIndex = 41
        Me.bt0105.Tag = "0105"
        Me.bt0105.UseVisualStyleBackColor = False
        '
        'bt0005
        '
        Me.bt0005.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0005.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0005.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0005.ForeColor = System.Drawing.Color.DimGray
        Me.bt0005.Location = New System.Drawing.Point(12, 212)
        Me.bt0005.Name = "bt0005"
        Me.bt0005.Size = New System.Drawing.Size(36, 36)
        Me.bt0005.TabIndex = 40
        Me.bt0005.Tag = "0005"
        Me.bt0005.UseVisualStyleBackColor = False
        '
        'bt0706
        '
        Me.bt0706.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0706.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0706.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0706.ForeColor = System.Drawing.Color.DimGray
        Me.bt0706.Location = New System.Drawing.Point(264, 248)
        Me.bt0706.Name = "bt0706"
        Me.bt0706.Size = New System.Drawing.Size(36, 36)
        Me.bt0706.TabIndex = 55
        Me.bt0706.Tag = "0706"
        Me.bt0706.UseVisualStyleBackColor = False
        '
        'bt0606
        '
        Me.bt0606.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0606.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0606.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0606.ForeColor = System.Drawing.Color.DimGray
        Me.bt0606.Location = New System.Drawing.Point(228, 248)
        Me.bt0606.Name = "bt0606"
        Me.bt0606.Size = New System.Drawing.Size(36, 36)
        Me.bt0606.TabIndex = 54
        Me.bt0606.Tag = "0606"
        Me.bt0606.UseVisualStyleBackColor = False
        '
        'bt0506
        '
        Me.bt0506.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0506.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0506.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0506.ForeColor = System.Drawing.Color.DimGray
        Me.bt0506.Location = New System.Drawing.Point(192, 248)
        Me.bt0506.Name = "bt0506"
        Me.bt0506.Size = New System.Drawing.Size(36, 36)
        Me.bt0506.TabIndex = 53
        Me.bt0506.Tag = "0506"
        Me.bt0506.UseVisualStyleBackColor = False
        '
        'bt0406
        '
        Me.bt0406.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0406.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0406.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0406.ForeColor = System.Drawing.Color.DimGray
        Me.bt0406.Location = New System.Drawing.Point(156, 248)
        Me.bt0406.Name = "bt0406"
        Me.bt0406.Size = New System.Drawing.Size(36, 36)
        Me.bt0406.TabIndex = 52
        Me.bt0406.Tag = "0406"
        Me.bt0406.UseVisualStyleBackColor = False
        '
        'bt0306
        '
        Me.bt0306.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0306.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0306.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0306.ForeColor = System.Drawing.Color.DimGray
        Me.bt0306.Location = New System.Drawing.Point(120, 248)
        Me.bt0306.Name = "bt0306"
        Me.bt0306.Size = New System.Drawing.Size(36, 36)
        Me.bt0306.TabIndex = 51
        Me.bt0306.Tag = "0306"
        Me.bt0306.UseVisualStyleBackColor = False
        '
        'bt0206
        '
        Me.bt0206.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0206.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0206.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0206.ForeColor = System.Drawing.Color.DimGray
        Me.bt0206.Location = New System.Drawing.Point(84, 248)
        Me.bt0206.Name = "bt0206"
        Me.bt0206.Size = New System.Drawing.Size(36, 36)
        Me.bt0206.TabIndex = 50
        Me.bt0206.Tag = "0206"
        Me.bt0206.UseVisualStyleBackColor = False
        '
        'bt0106
        '
        Me.bt0106.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0106.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0106.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0106.ForeColor = System.Drawing.Color.DimGray
        Me.bt0106.Location = New System.Drawing.Point(48, 248)
        Me.bt0106.Name = "bt0106"
        Me.bt0106.Size = New System.Drawing.Size(36, 36)
        Me.bt0106.TabIndex = 49
        Me.bt0106.Tag = "0106"
        Me.bt0106.UseVisualStyleBackColor = False
        '
        'bt0006
        '
        Me.bt0006.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0006.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0006.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0006.ForeColor = System.Drawing.Color.DimGray
        Me.bt0006.Location = New System.Drawing.Point(12, 248)
        Me.bt0006.Name = "bt0006"
        Me.bt0006.Size = New System.Drawing.Size(36, 36)
        Me.bt0006.TabIndex = 48
        Me.bt0006.Tag = "0006"
        Me.bt0006.UseVisualStyleBackColor = False
        '
        'bt0707
        '
        Me.bt0707.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0707.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0707.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0707.ForeColor = System.Drawing.Color.DimGray
        Me.bt0707.Location = New System.Drawing.Point(264, 284)
        Me.bt0707.Name = "bt0707"
        Me.bt0707.Size = New System.Drawing.Size(36, 36)
        Me.bt0707.TabIndex = 63
        Me.bt0707.Tag = "0707"
        Me.bt0707.UseVisualStyleBackColor = False
        '
        'bt0607
        '
        Me.bt0607.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0607.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0607.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0607.ForeColor = System.Drawing.Color.DimGray
        Me.bt0607.Location = New System.Drawing.Point(228, 284)
        Me.bt0607.Name = "bt0607"
        Me.bt0607.Size = New System.Drawing.Size(36, 36)
        Me.bt0607.TabIndex = 62
        Me.bt0607.Tag = "0607"
        Me.bt0607.UseVisualStyleBackColor = False
        '
        'bt0507
        '
        Me.bt0507.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0507.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0507.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0507.ForeColor = System.Drawing.Color.DimGray
        Me.bt0507.Location = New System.Drawing.Point(192, 284)
        Me.bt0507.Name = "bt0507"
        Me.bt0507.Size = New System.Drawing.Size(36, 36)
        Me.bt0507.TabIndex = 61
        Me.bt0507.Tag = "0507"
        Me.bt0507.UseVisualStyleBackColor = False
        '
        'bt0407
        '
        Me.bt0407.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0407.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0407.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0407.ForeColor = System.Drawing.Color.DimGray
        Me.bt0407.Location = New System.Drawing.Point(156, 284)
        Me.bt0407.Name = "bt0407"
        Me.bt0407.Size = New System.Drawing.Size(36, 36)
        Me.bt0407.TabIndex = 60
        Me.bt0407.Tag = "0407"
        Me.bt0407.UseVisualStyleBackColor = False
        '
        'bt0307
        '
        Me.bt0307.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0307.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0307.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0307.ForeColor = System.Drawing.Color.DimGray
        Me.bt0307.Location = New System.Drawing.Point(120, 284)
        Me.bt0307.Name = "bt0307"
        Me.bt0307.Size = New System.Drawing.Size(36, 36)
        Me.bt0307.TabIndex = 59
        Me.bt0307.Tag = "0307"
        Me.bt0307.UseVisualStyleBackColor = False
        '
        'bt0207
        '
        Me.bt0207.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0207.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0207.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0207.ForeColor = System.Drawing.Color.DimGray
        Me.bt0207.Location = New System.Drawing.Point(84, 284)
        Me.bt0207.Name = "bt0207"
        Me.bt0207.Size = New System.Drawing.Size(36, 36)
        Me.bt0207.TabIndex = 58
        Me.bt0207.Tag = "0207"
        Me.bt0207.UseVisualStyleBackColor = False
        '
        'bt0107
        '
        Me.bt0107.BackColor = System.Drawing.Color.SandyBrown
        Me.bt0107.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0107.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0107.ForeColor = System.Drawing.Color.DimGray
        Me.bt0107.Location = New System.Drawing.Point(48, 284)
        Me.bt0107.Name = "bt0107"
        Me.bt0107.Size = New System.Drawing.Size(36, 36)
        Me.bt0107.TabIndex = 57
        Me.bt0107.Tag = "0107"
        Me.bt0107.UseVisualStyleBackColor = False
        '
        'bt0007
        '
        Me.bt0007.BackColor = System.Drawing.Color.SaddleBrown
        Me.bt0007.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bt0007.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt0007.ForeColor = System.Drawing.Color.DimGray
        Me.bt0007.Location = New System.Drawing.Point(12, 284)
        Me.bt0007.Name = "bt0007"
        Me.bt0007.Size = New System.Drawing.Size(36, 36)
        Me.bt0007.TabIndex = 56
        Me.bt0007.Tag = "0007"
        Me.bt0007.UseVisualStyleBackColor = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChessToolStripMenuItem, Me.TimerToolStripMenuItem, Me.OptionsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(412, 24)
        Me.MenuStrip1.TabIndex = 64
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ChessToolStripMenuItem
        '
        Me.ChessToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewGameToolStripMenuItem, Me.CurrentScoreToolStripMenuItem})
        Me.ChessToolStripMenuItem.Name = "ChessToolStripMenuItem"
        Me.ChessToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.ChessToolStripMenuItem.Text = "Chess"
        '
        'NewGameToolStripMenuItem
        '
        Me.NewGameToolStripMenuItem.Name = "NewGameToolStripMenuItem"
        Me.NewGameToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.NewGameToolStripMenuItem.Text = "New Game"
        '
        'CurrentScoreToolStripMenuItem
        '
        Me.CurrentScoreToolStripMenuItem.Name = "CurrentScoreToolStripMenuItem"
        Me.CurrentScoreToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.CurrentScoreToolStripMenuItem.Text = "Current Score"
        '
        'TimerToolStripMenuItem
        '
        Me.TimerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.RemoveTimerToolStripMenuItem})
        Me.TimerToolStripMenuItem.Name = "TimerToolStripMenuItem"
        Me.TimerToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.TimerToolStripMenuItem.Text = "Set Timer"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(151, 22)
        Me.ToolStripMenuItem2.Text = "2:00"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(151, 22)
        Me.ToolStripMenuItem3.Text = "5:00"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(151, 22)
        Me.ToolStripMenuItem4.Text = "10:00"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(151, 22)
        Me.ToolStripMenuItem6.Text = "20:00"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(151, 22)
        Me.ToolStripMenuItem7.Text = "30:00"
        '
        'RemoveTimerToolStripMenuItem
        '
        Me.RemoveTimerToolStripMenuItem.Name = "RemoveTimerToolStripMenuItem"
        Me.RemoveTimerToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.RemoveTimerToolStripMenuItem.Text = "Remove Timer"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangeMoveGlowToolStripMenuItem, Me.ChangeBoardColorToolStripMenuItem, Me.RotateBoardToolStripMenuItem, Me.CreditsToolStripMenuItem})
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.OptionsToolStripMenuItem.Text = "Options"
        '
        'ChangeMoveGlowToolStripMenuItem
        '
        Me.ChangeMoveGlowToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RoyalBluedefaultToolStripMenuItem, Me.CyanToolStripMenuItem, Me.DarkKhakiToolStripMenuItem, Me.HotPinkToolStripMenuItem, Me.LimeGreenToolStripMenuItem, Me.RedToolStripMenuItem, Me.SilverToolStripMenuItem, Me.YellowToolStripMenuItem, Me.CustomColorToolStripMenuItem})
        Me.ChangeMoveGlowToolStripMenuItem.Name = "ChangeMoveGlowToolStripMenuItem"
        Me.ChangeMoveGlowToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ChangeMoveGlowToolStripMenuItem.Text = "Change Move Glow"
        Me.ChangeMoveGlowToolStripMenuItem.ToolTipText = "Change the colour of the squares you are able to select"
        '
        'RoyalBluedefaultToolStripMenuItem
        '
        Me.RoyalBluedefaultToolStripMenuItem.Name = "RoyalBluedefaultToolStripMenuItem"
        Me.RoyalBluedefaultToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.RoyalBluedefaultToolStripMenuItem.Text = "Royal Blue (default)"
        '
        'CyanToolStripMenuItem
        '
        Me.CyanToolStripMenuItem.Name = "CyanToolStripMenuItem"
        Me.CyanToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.CyanToolStripMenuItem.Text = "Cyan"
        '
        'DarkKhakiToolStripMenuItem
        '
        Me.DarkKhakiToolStripMenuItem.Name = "DarkKhakiToolStripMenuItem"
        Me.DarkKhakiToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.DarkKhakiToolStripMenuItem.Text = "Dark Khaki"
        '
        'HotPinkToolStripMenuItem
        '
        Me.HotPinkToolStripMenuItem.Name = "HotPinkToolStripMenuItem"
        Me.HotPinkToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.HotPinkToolStripMenuItem.Text = "Hot Pink"
        '
        'LimeGreenToolStripMenuItem
        '
        Me.LimeGreenToolStripMenuItem.Name = "LimeGreenToolStripMenuItem"
        Me.LimeGreenToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.LimeGreenToolStripMenuItem.Text = "Lime Green"
        '
        'RedToolStripMenuItem
        '
        Me.RedToolStripMenuItem.Name = "RedToolStripMenuItem"
        Me.RedToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.RedToolStripMenuItem.Text = "Red"
        '
        'SilverToolStripMenuItem
        '
        Me.SilverToolStripMenuItem.Name = "SilverToolStripMenuItem"
        Me.SilverToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.SilverToolStripMenuItem.Text = "Silver"
        '
        'YellowToolStripMenuItem
        '
        Me.YellowToolStripMenuItem.Name = "YellowToolStripMenuItem"
        Me.YellowToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.YellowToolStripMenuItem.Text = "Yellow"
        '
        'CustomColorToolStripMenuItem
        '
        Me.CustomColorToolStripMenuItem.Name = "CustomColorToolStripMenuItem"
        Me.CustomColorToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.CustomColorToolStripMenuItem.Text = "Custom Color"
        '
        'ChangeBoardColorToolStripMenuItem
        '
        Me.ChangeBoardColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClassicToolStripMenuItem, Me.BlackWhiteToolStripMenuItem, Me.RolloutBoardToolStripMenuItem, Me.EricsCustomColorToolStripMenuItem, Me.CustomBoardToolStripMenuItem})
        Me.ChangeBoardColorToolStripMenuItem.Name = "ChangeBoardColorToolStripMenuItem"
        Me.ChangeBoardColorToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ChangeBoardColorToolStripMenuItem.Text = "Change Board Color"
        Me.ChangeBoardColorToolStripMenuItem.ToolTipText = "Change the colour of the background"
        '
        'ClassicToolStripMenuItem
        '
        Me.ClassicToolStripMenuItem.Name = "ClassicToolStripMenuItem"
        Me.ClassicToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.ClassicToolStripMenuItem.Text = "Classic"
        '
        'BlackWhiteToolStripMenuItem
        '
        Me.BlackWhiteToolStripMenuItem.Name = "BlackWhiteToolStripMenuItem"
        Me.BlackWhiteToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.BlackWhiteToolStripMenuItem.Text = "Black and White"
        '
        'RolloutBoardToolStripMenuItem
        '
        Me.RolloutBoardToolStripMenuItem.Name = "RolloutBoardToolStripMenuItem"
        Me.RolloutBoardToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.RolloutBoardToolStripMenuItem.Text = "Rollout Board"
        '
        'EricsCustomColorToolStripMenuItem
        '
        Me.EricsCustomColorToolStripMenuItem.Name = "EricsCustomColorToolStripMenuItem"
        Me.EricsCustomColorToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.EricsCustomColorToolStripMenuItem.Text = "Eric's Custom Color"
        Me.EricsCustomColorToolStripMenuItem.ToolTipText = "God please don't choose this colour unless you truly hate yourself"
        '
        'RotateBoardToolStripMenuItem
        '
        Me.RotateBoardToolStripMenuItem.CheckOnClick = True
        Me.RotateBoardToolStripMenuItem.Name = "RotateBoardToolStripMenuItem"
        Me.RotateBoardToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.RotateBoardToolStripMenuItem.Text = "Rotate Board"
        Me.RotateBoardToolStripMenuItem.ToolTipText = "The board will always face the player whose turn it is"
        '
        'CreditsToolStripMenuItem
        '
        Me.CreditsToolStripMenuItem.Name = "CreditsToolStripMenuItem"
        Me.CreditsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.CreditsToolStripMenuItem.Text = "Credits"
        '
        'btTopTime
        '
        Me.btTopTime.Enabled = False
        Me.btTopTime.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btTopTime.Location = New System.Drawing.Point(306, 68)
        Me.btTopTime.Name = "btTopTime"
        Me.btTopTime.Size = New System.Drawing.Size(94, 36)
        Me.btTopTime.TabIndex = 65
        Me.btTopTime.Text = "--:--"
        Me.btTopTime.UseVisualStyleBackColor = True
        '
        'btBottomTime
        '
        Me.btBottomTime.Enabled = False
        Me.btBottomTime.Font = New System.Drawing.Font("Century Gothic", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btBottomTime.Location = New System.Drawing.Point(306, 245)
        Me.btBottomTime.Name = "btBottomTime"
        Me.btBottomTime.Size = New System.Drawing.Size(94, 36)
        Me.btBottomTime.TabIndex = 66
        Me.btBottomTime.Text = "--:--"
        Me.btBottomTime.UseVisualStyleBackColor = True
        '
        'tmOneSecond
        '
        Me.tmOneSecond.Interval = 1000
        '
        'CustomBoardToolStripMenuItem
        '
        Me.CustomBoardToolStripMenuItem.Name = "CustomBoardToolStripMenuItem"
        Me.CustomBoardToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.CustomBoardToolStripMenuItem.Text = "Custom Board"
        '
        'fmChess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(412, 331)
        Me.Controls.Add(Me.btBottomTime)
        Me.Controls.Add(Me.btTopTime)
        Me.Controls.Add(Me.bt0707)
        Me.Controls.Add(Me.bt0607)
        Me.Controls.Add(Me.bt0507)
        Me.Controls.Add(Me.bt0407)
        Me.Controls.Add(Me.bt0307)
        Me.Controls.Add(Me.bt0207)
        Me.Controls.Add(Me.bt0107)
        Me.Controls.Add(Me.bt0007)
        Me.Controls.Add(Me.bt0706)
        Me.Controls.Add(Me.bt0606)
        Me.Controls.Add(Me.bt0506)
        Me.Controls.Add(Me.bt0406)
        Me.Controls.Add(Me.bt0306)
        Me.Controls.Add(Me.bt0206)
        Me.Controls.Add(Me.bt0106)
        Me.Controls.Add(Me.bt0006)
        Me.Controls.Add(Me.bt0705)
        Me.Controls.Add(Me.bt0605)
        Me.Controls.Add(Me.bt0505)
        Me.Controls.Add(Me.bt0405)
        Me.Controls.Add(Me.bt0305)
        Me.Controls.Add(Me.bt0205)
        Me.Controls.Add(Me.bt0105)
        Me.Controls.Add(Me.bt0005)
        Me.Controls.Add(Me.bt0704)
        Me.Controls.Add(Me.bt0604)
        Me.Controls.Add(Me.bt0504)
        Me.Controls.Add(Me.bt0404)
        Me.Controls.Add(Me.bt0304)
        Me.Controls.Add(Me.bt0204)
        Me.Controls.Add(Me.bt0104)
        Me.Controls.Add(Me.bt0004)
        Me.Controls.Add(Me.bt0703)
        Me.Controls.Add(Me.bt0603)
        Me.Controls.Add(Me.bt0503)
        Me.Controls.Add(Me.bt0403)
        Me.Controls.Add(Me.bt0303)
        Me.Controls.Add(Me.bt0203)
        Me.Controls.Add(Me.bt0103)
        Me.Controls.Add(Me.bt0003)
        Me.Controls.Add(Me.bt0702)
        Me.Controls.Add(Me.bt0602)
        Me.Controls.Add(Me.bt0502)
        Me.Controls.Add(Me.bt0402)
        Me.Controls.Add(Me.bt0302)
        Me.Controls.Add(Me.bt0202)
        Me.Controls.Add(Me.bt0102)
        Me.Controls.Add(Me.bt0002)
        Me.Controls.Add(Me.bt0701)
        Me.Controls.Add(Me.bt0601)
        Me.Controls.Add(Me.bt0501)
        Me.Controls.Add(Me.bt0401)
        Me.Controls.Add(Me.bt0301)
        Me.Controls.Add(Me.bt0201)
        Me.Controls.Add(Me.bt0101)
        Me.Controls.Add(Me.bt0001)
        Me.Controls.Add(Me.bt0700)
        Me.Controls.Add(Me.bt0600)
        Me.Controls.Add(Me.bt0500)
        Me.Controls.Add(Me.bt0400)
        Me.Controls.Add(Me.bt0300)
        Me.Controls.Add(Me.bt0200)
        Me.Controls.Add(Me.bt0100)
        Me.Controls.Add(Me.bt0000)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "fmChess"
        Me.Text = "Chess"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bt0000 As System.Windows.Forms.Button
    Friend WithEvents bt0100 As System.Windows.Forms.Button
    Friend WithEvents bt0200 As System.Windows.Forms.Button
    Friend WithEvents bt0300 As System.Windows.Forms.Button
    Friend WithEvents bt0400 As System.Windows.Forms.Button
    Friend WithEvents bt0500 As System.Windows.Forms.Button
    Friend WithEvents bt0600 As System.Windows.Forms.Button
    Friend WithEvents bt0700 As System.Windows.Forms.Button
    Friend WithEvents bt0701 As System.Windows.Forms.Button
    Friend WithEvents bt0601 As System.Windows.Forms.Button
    Friend WithEvents bt0501 As System.Windows.Forms.Button
    Friend WithEvents bt0401 As System.Windows.Forms.Button
    Friend WithEvents bt0301 As System.Windows.Forms.Button
    Friend WithEvents bt0201 As System.Windows.Forms.Button
    Friend WithEvents bt0101 As System.Windows.Forms.Button
    Friend WithEvents bt0001 As System.Windows.Forms.Button
    Friend WithEvents bt0702 As System.Windows.Forms.Button
    Friend WithEvents bt0602 As System.Windows.Forms.Button
    Friend WithEvents bt0502 As System.Windows.Forms.Button
    Friend WithEvents bt0402 As System.Windows.Forms.Button
    Friend WithEvents bt0302 As System.Windows.Forms.Button
    Friend WithEvents bt0202 As System.Windows.Forms.Button
    Friend WithEvents bt0102 As System.Windows.Forms.Button
    Friend WithEvents bt0002 As System.Windows.Forms.Button
    Friend WithEvents bt0703 As System.Windows.Forms.Button
    Friend WithEvents bt0603 As System.Windows.Forms.Button
    Friend WithEvents bt0503 As System.Windows.Forms.Button
    Friend WithEvents bt0403 As System.Windows.Forms.Button
    Friend WithEvents bt0303 As System.Windows.Forms.Button
    Friend WithEvents bt0203 As System.Windows.Forms.Button
    Friend WithEvents bt0103 As System.Windows.Forms.Button
    Friend WithEvents bt0003 As System.Windows.Forms.Button
    Friend WithEvents bt0704 As System.Windows.Forms.Button
    Friend WithEvents bt0604 As System.Windows.Forms.Button
    Friend WithEvents bt0504 As System.Windows.Forms.Button
    Friend WithEvents bt0404 As System.Windows.Forms.Button
    Friend WithEvents bt0304 As System.Windows.Forms.Button
    Friend WithEvents bt0204 As System.Windows.Forms.Button
    Friend WithEvents bt0104 As System.Windows.Forms.Button
    Friend WithEvents bt0004 As System.Windows.Forms.Button
    Friend WithEvents bt0705 As System.Windows.Forms.Button
    Friend WithEvents bt0605 As System.Windows.Forms.Button
    Friend WithEvents bt0505 As System.Windows.Forms.Button
    Friend WithEvents bt0405 As System.Windows.Forms.Button
    Friend WithEvents bt0305 As System.Windows.Forms.Button
    Friend WithEvents bt0205 As System.Windows.Forms.Button
    Friend WithEvents bt0105 As System.Windows.Forms.Button
    Friend WithEvents bt0005 As System.Windows.Forms.Button
    Friend WithEvents bt0706 As System.Windows.Forms.Button
    Friend WithEvents bt0606 As System.Windows.Forms.Button
    Friend WithEvents bt0506 As System.Windows.Forms.Button
    Friend WithEvents bt0406 As System.Windows.Forms.Button
    Friend WithEvents bt0306 As System.Windows.Forms.Button
    Friend WithEvents bt0206 As System.Windows.Forms.Button
    Friend WithEvents bt0106 As System.Windows.Forms.Button
    Friend WithEvents bt0006 As System.Windows.Forms.Button
    Friend WithEvents bt0707 As System.Windows.Forms.Button
    Friend WithEvents bt0607 As System.Windows.Forms.Button
    Friend WithEvents bt0507 As System.Windows.Forms.Button
    Friend WithEvents bt0407 As System.Windows.Forms.Button
    Friend WithEvents bt0307 As System.Windows.Forms.Button
    Friend WithEvents bt0207 As System.Windows.Forms.Button
    Friend WithEvents bt0107 As System.Windows.Forms.Button
    Friend WithEvents bt0007 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ChessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewGameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeMoveGlowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RoyalBluedefaultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HotPinkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CyanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LimeGreenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YellowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DarkKhakiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SilverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeBoardColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassicToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlackWhiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EricsCustomColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RolloutBoardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CurrentScoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btTopTime As System.Windows.Forms.Button
    Friend WithEvents TimerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btBottomTime As System.Windows.Forms.Button
    Friend WithEvents tmOneSecond As System.Windows.Forms.Timer
    Friend WithEvents RemoveTimerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RotateBoardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cdMoveGlow As System.Windows.Forms.ColorDialog
    Friend WithEvents cdDarkSquare As System.Windows.Forms.ColorDialog
    Friend WithEvents cdLightSquare As System.Windows.Forms.ColorDialog
    Friend WithEvents CustomBoardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
